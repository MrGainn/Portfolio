finalinput = '';
finalkwadraatinput='';
finalsin='';
finalexpo='';
finalinverse='';
finalcos='';
finallog='';
finaltan='';
finalsqrt = '';
finalprimitieve = "";
ax2 = "false";
sine= "false";
cosine= "false";
tangent="fasle";
wortel= "false";
kwadraat="false";
exponent="false";
invers= "false";
logaritme="false";
formula_ax ="false";
formula_kwadratisch = "false";
formula_cos= "false";
formula_log= "false";
formula_sin= "false";
formula_tan="false";
formula_sqrt="false";
formula_iverse="false";
formula_exponentieel="false";
formula_primitiveax = "false";
formula_primitivekwadratisch = "false";
formula_primitivesin = "false";
formula_primitiveexpo = "false";
formula_primitivecos = "false";
aantalfuncties = 0;


function chosetypeax(){

  document.getElementById("formula").innerHTML = '<br><input type="text" id="rc" type="number" size="1"><span>x +</span><input type="text" id="verschuiving" type="number" size="1">';
  formula_ax = "true";
}
function chosetypekwadratisch(){
  document.getElementById("formula").innerHTML = '<br><input type="text" id="ax" type="number"size="1" required><span>x<sup>2</sup> +</span><input type="text" id="bx" type="number"size="1"><span>x +</span><input type="text" id="c"size="1">';
  formula_kwadratisch = "true";
}
function chosetypesin(){
  document.getElementById("formula").innerHTML = '<br><input type="text" id="a" type="number" size="1"><span>sin(x) +</span><input type="text" id="b" type="number">';
  formula_sin = "true";
}
function chosetypeexponentieel(){
  document.getElementById("formula").innerHTML = ' <br><input type="text" id="a2" type="number" size="1"><span> e<sup>x</sup> +</span><input type="text" id="b2" type="number">';
  formula_exponentieel = "true";
}
function chosetypeiverse(){
  document.getElementById("formula").innerHTML = '<br><input type="text" id="a3" type="number" size="1"><span> 1/x +</span><input type="text" id="b3" type="number">';
  formula_iverse = "true";
}
function chosetypecos(){
  document.getElementById("formula").innerHTML = '<br><input type="text" id="a4" type="number" size="1"><span> cos(x) +</span><input type="text" id="b4" type="number">';
  formula_cos = "true";
}
function chosetypelog(){
  document.getElementById("formula").innerHTML = '<br><br><input type="text" id="a5" type="number" size="1"><span> log(x) +</span><input type="text" id="b5" type="number">';
  formula_log = "true";
}
function chosetypetan(){
  document.getElementById("formula").innerHTML = '<br><input type="text" id="a6" type="number" size="1"><span> tan(x) +</span><input type="text" id="b6" type="number">';
  formula_tan = "true";
}
function chosetypesqrt(){
  document.getElementById("formula").innerHTML = '<br><input type="text" id="a7" type="number" size="1"><span> √x +</span><input type="text" id="b7" type="number">';
  formula_sqrt = "true";
}
function primitiveax (){
  formula_primitiveax= "true";
  update();
}
function primitiveaxkwadraat(){
  formula_primitivekwadratisch = "true";
  update();
}
function primitivesin(){
  formula_primitivesin = "true";
  update();
}
function primitiveexpo(){
  formula_primitiveexpo = "true";
  update();
}
function primitivecos(){
  formula_primitivecos = "true";
  update();
}

var slider = document.getElementById("slider").value;
var slider2 = document.getElementById("slider");

var interval = 0.1;

slider2.onchange = function(event){
  slider = document.getElementById("slider").value;
  document.getElementById("slidervalue").innerHTML = slider;
}


function destroy() {
  myBarChart.destroy();
}
function update() {

  destroy();
sameformula = 0;

formulas = [];


  if (formula_ax == "true") {
    rc = parseInt((document.getElementById("rc")).value*1000)/1000;
    verschuiving = parseInt((document.getElementById("verschuiving").value*1000))/1000;
    finalinput = "f(x) = "+rc + "x + " + verschuiving;
    ax2 = "true";
    aantalfuncties +=1;
    document.getElementById("primitive").innerHTML += '<button onclick = "primitiveax()">primitiveer ax+b</buttton>';
  }
   if (formula_kwadratisch == "true") {
    ax = parseInt((document.getElementById("ax").value*1000))/1000;
    bx = parseInt((document.getElementById("bx").value*1000))/1000;
    c = parseInt((document.getElementById("c").value*1000))/1000;
    finalkwadraatinput = "f(x) = "+ax + "x^2 + " + bx + "x + "+c;
    kwadraat="true";
    aantalfuncties +=1;
    document.getElementById("primitive").innerHTML += '<button onclick = "primitiveaxkwadraat()">primitiveer ax^2+bx+c</buttton>';

  }
   if (formula_sin == "true") {
    a = parseInt((document.getElementById("a").value*1000))/1000;
    b = parseInt((document.getElementById("b").value*1000))/1000;

    finalsin = "f(x) = "+a + "sin(x)+ " + b;
    sine="true";
    aantalfuncties +=1;
    document.getElementById("primitive").innerHTML += '<button onclick = "primitivesin()">primitiveer sin</buttton>';
  }
   if (formula_exponentieel == "true") {
    a2 = parseInt((document.getElementById("a2").value*1000))/1000;
    b2 = parseInt((document.getElementById("b2").value*1000))/1000;

    finalexpo = "f(x) = "+a2 + "e^x+^x +" + b2;
    exponent="true";
    aantalfuncties +=1;
    document.getElementById("primitive").innerHTML += '<button onclick = "primitiveexpo()">primitiveer exponentieel</buttton>';
  }
   if (formula_iverse == "true") {
    a3 = parseInt((document.getElementById("a3").value*1000))/1000;
    b3 = parseInt((document.getElementById("b3").value*1000))/1000;

    finalinverse = "f(x) = "+a3 + "(1/x) +" + b3;
    invers="true";
    aantalfuncties +=1;
  }
   if (formula_cos == "true") {
    a4 = parseInt((document.getElementById("a4").value*1000))/1000;
    b4 = parseInt((document.getElementById("b4").value*1000))/1000;

    finalcos = "f(x) = "+a4 + "cos(x) +" + b4;
    cosine="true";
    aantalfuncties +=1;
    document.getElementById("primitive").innerHTML += '<button onclick = "primitivecos()">primitiveer cos</buttton>';
  }
   if (formula_log == "true") {
    a5 = parseInt((document.getElementById("a5").value*1000))/1000;
    b5 = parseInt((document.getElementById("b5").value*1000))/1000;

    finallog = "f(x) = "+a5 + "log(x) +" + b5;
    logaritme="true";
    aantalfuncties +=1;
  }
   if (formula_tan == "true") {
    a6 = parseInt((document.getElementById("a6").value*1000))/1000;
    b6 = parseInt((document.getElementById("b6").value*1000))/1000;

    finaltan = "f(x) = "+a6 + "tan(x) +" + b6;
    tangent="true";
    aantalfuncties +=1;
  }
   if (formula_sqrt == "true") {
    a7 = parseInt((document.getElementById("a7").value*1000))/1000;
    b7 = parseInt((document.getElementById("b7").value*1000))/1000;
    finalsqrt = "f(x) = "+a7 + "sqrt(x) +" + b7;
    wortel="true";
    aantalfuncties +=1;
  }
  interval = parseInt((100*document.querySelector('input[name="interval"]:checked').value))/100;

  var num = 0;
  list = [0];
  for (var i = 0; i < (slider*(1/interval)); i++) {
    num += interval;
    list.push(Math.round(num*100)/100);
  }
data.labels = list;


if (formula_primitiveax== "true") {
  finalprimitieveax = "ʃ ("+rc + "x + " + verschuiving+")dx";
  var iets ={
      label: finalprimitieveax,
      function: function(x) {
        return (rc*((x*x)/2) + x*verschuiving);
      },
      borderColor: "rgba(255,0,0, 1)",
      data: [],
      fill: false
    };
  data.datasets.push(iets);
  formula_primitiveax = "false";
  aantalfuncties +=1
}
if (formula_primitivekwadratisch== "true") {
  finalprimitievekwadratisch = "ʃ ("+ax + "x^2 + " + bx+"x +" + c+")dx";
  var iets ={
      label: finalprimitievekwadratisch,
      function: function(x) {
        return (ax/3*(x*x*x) + (x*x)*bx/2+c*x);
      },
      borderColor: "rgba(255,0,0, 1)",
      data: [],
      fill: false
    };
    data.datasets.push(iets);
    formula_primitivekwadratisch = "false";
    aantalfuncties +=1
  }
    if (formula_primitivesin== "true") {
      finalprimitievesin = "ʃ ("+a + "sin(x)+ " + b+")dx";
      var iets ={
          label: finalprimitievesin,
          function: function(x) {
            return (-1*a*Math.cos(x)+b*x);
          },
          borderColor: "rgba(255,0,0, 1)",
          data: [],
          fill: false
        };
        data.datasets.push(iets);
        formula_primitivesin = "false";
        aantalfuncties +=1
      }
        if (formula_primitiveexpo== "true") {
          finalprimitieveexpo = "ʃ ("+a2 + "e^x+^x +" + b2+")dx";
          var iets ={
              label: finalprimitieveexpo,
              function: function(x) {
                return (a2*Math.exp(x)+b2*x);
              },
              borderColor: "rgba(255,0,0, 1)",
              data: [],
              fill: false
            };
            data.datasets.push(iets);
            formula_primitiveexpo = "false";
            aantalfuncties +=1
          }

            if (formula_primitivecos== "true") {
              finalprimitievecos = "ʃ ("+a4 + "cos(x) +" + b4+")dx";
              var iets ={
                  label: finalprimitievecos,
                  function: function(x) {
                    return (a4*Math.sin(x)+b4*x);
                  },
                  borderColor: "rgba(255,0,0, 1)",
                  data: [],
                  fill: false
                };
                data.datasets.push(iets);
                formula_primitivecos = "false";
                aantalfuncties +=1;
              }




if (ax2 == "true") {
  var iets ={
      label: finalinput,
      function: function(x) {
        return (rc*x + verschuiving);
      },
      borderColor: "rgba(255,0,0, 1)",
      data: [],
      fill: false
    };
  data.datasets.push(iets);
  ax2 = "false";
  formula_ax = "false";
}
 if (kwadraat == "true") {
  var iets ={
    label: finalkwadraatinput,
    function: function(x) {
      return (ax*x*x + bx*x +c);
    },
    borderColor: "rgba(128,0,128, 1)",
    data: [],
    fill: false
  };
  data.datasets.push(iets);
  kwadraat = "false";
  formula_kwadratisch = "false";
}
 if (exponent == "true") {
  var iets =   {
      label: finalexpo,
      function: function(x) {
        return a2*Math.exp(x)+b2;
      },
      borderColor: "rgba(255,0,255, 1)",
      data: [],
      fill: false
    };
    data.datasets.push(iets);
    exponent = "false";
    formula_exponentieel = "false";
}
 if (sine == "true") {
  var iets= {
    label: finalsin,
    function: function(x) {
      return a*Math.sin(x)+b;
    },
    borderColor: "rgba(0,255,255, 1)",
    data: [],
    fill: false
  };
data.datasets.push(iets);
sine= "false";
formula_sin = "false";
}
 if (cosine == "true") {
  var iets={
    label: finalcos,
    function: function(x) {
      return a4*Math.cos(x)+b4;
    },
    borderColor: "rgba(30,144,255, 1)",
    data: [],
    fill: false
  };
  data.datasets.push(iets);
  cosine = "false";
  formula_cos = "false";
}
 if (logaritme == "true") {
  var iets =  {
      label: finallog,
      function: function(x) {
        return a5*Math.log(x)+b5;
      },
      borderColor: "rgba(205,92,92, 1)",
      data: [],
      fill: false
    };
    data.datasets.push(iets);
    logaritme = "false";
    formula_log = "false";
}
 if (invers == "true") {
  var iets = {
    label: finalinverse,
    function: function(x) {
      return a3/x+b3;
    },
    borderColor: "rgba(255,20,147, 1)",
    data: [],
    fill: false
  };
  data.datasets.push(iets);
  invers = "false";
  formula_inverse = "false";
}
 if (tangent == "true") {
  var iets = {
    label: finaltan,
    function: function(x) {
      return a6*Math.tan(x)+b6;
    },
    borderColor: "rgba(255,182,193, 1)",
    data: [],
    fill: false
  };
    data.datasets.push(iets);
    tangent = "false";
    formula_tan = "false";
}
 if (wortel == "true") {
  var iets ={
    label: finalsqrt,
    function: function(x) {
      return a7*Math.sqrt(x)+b7;
    },
    borderColor: "rgba(255,182,193, 1)",
    data: [],
    fill: false
  };
data.datasets.push(iets);
wortel = "false";
formula_sqrt= "false";
}


for (var i = 0; i < aantalfuncties; i++) {
  data.datasets[i].data = [];
}


Chart.pluginService.register({
  beforeInit: function(chart) {
    var data = chart.config.data;
    for (var i = 0; i < data.datasets.length; i++) {
      for (var j = 0; j < data.labels.length; j++) {
        var fct = data.datasets[i].function,
          x = data.labels[j],
          y = fct(x);
        data.datasets[i].data.push(y);
      }
    }
  }
});

myBarChart = new Chart(ctx, {
  type: 'line',
  data: data,
  options: {
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
console.log(data);
}

const canvas = document.getElementById("myChart");
const ctx = canvas.getContext("2d");

ctx.clearRect(0, 0, canvas.width, canvas.height);



var num = 0;
var list = [0];
for (var i = 0; i < (slider*(1/interval)); i++) {
  num += interval;
  list.push(Math.round(num*100)/100);
}



var data = {
labels: list,
datasets: []

};

Chart.pluginService.register({
beforeInit: function(chart) {
  var data = chart.config.data;
  for (var i = 0; i < data.datasets.length; i++) {
    for (var j = 0; j < data.labels.length; j++) {
      var fct = data.datasets[i].function,
        x = data.labels[j],
        y = fct(x);
      data.datasets[i].data.push(y);
    }
  }
}
});

var myBarChart = new Chart(ctx, {
type: 'line',
data: data,
options: {
  scales: {
    yAxes: [{
      ticks: {
        beginAtZero: true
      }
    }]
  }
}
});
