var aantal_kaarten = 20;
var layout = 5;
var state = 0;
var checker = "Je ma";
var img1 = 0;
var img2 = 0;
var remove = "False";
var last_id = "";
var aantal = 0;


  for (var i = 1; i <= aantal_kaarten; i++) {
  var x = document.createElement("IMG");
  x.setAttribute("src", "img/covered-card.png");
  x.setAttribute("id", i);
  x.setAttribute("class", "image");
  x.setAttribute("alt", "Een plaatje");
  x.setAttribute("onclick", "turn_card(this.id)");
  document.getElementById('center').appendChild(x);
  if (i % layout == 0) {
    var x = document.createElement("br");
    document.getElementById('center').appendChild(x);
  }
  }







  var numberset1 = [];
  var dict = {};
  for (var i = 1; i <= (aantal_kaarten / 2); i++) {
    numberset1.push(i);
    numberset1.push(i);
  }
  numberset1.sort((a,b) => 0.5 - Math.random());
  // Create 2 array's van numbers die random door elkaar staan
  for (var i = 0; i < aantal_kaarten; i++) {
      dict[(i + 1)] = numberset1[i];
  }
  console.log(dict);
// Dit blok zorgt ervoor dat een dictonary wordt gevult met random nummers
function turn_card(clicked_id) {
if (last_id == clicked_id) {
  return;
}

if (remove == "True") {
  img1.src = "img/covered-card.png";
  img2.src = "img/covered-card.png";
  remove = "False";
}
  if (state == 0) {
    img1 = document.getElementById(clicked_id);
    img1.src = "img/" + dict[clicked_id] + ".png";
    checker = dict[clicked_id];
    console.log("checker is: "+ checker);
    state = 1;
  }
else if (state == 1) {
  img2 = document.getElementById(clicked_id);
  img2.src = "img/" + dict[clicked_id] + ".png";
  var oplossing = dict[clicked_id];
  if (oplossing == checker) {
    aantal += 1;
  }
  else {
    remove = "True";
  }

  state = 0;
}

  last_id = clicked_id;
  if (aantal == (aantal_kaarten / 2)) {

    win();
  }
}
function win() {
  alert("you won");

}
