<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/main.css">
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <script type="text/javascript">
    function autoclicker(){
      document.getElementById("button21").click();
    }
    </script>
    <?php
    $list = array();



$id = $_GET['id'];


if (!isset($_GET['type'])) {
  $type = "Public";
}
else {
  $type = $_GET['type'];
}

require '../dbh/enquetedbh.php';

if ($type == "Private") {
  $sql = "SELECT username, title, result, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10 FROM enquete WHERE hexa = '$id'";
          $result = $conn->query($sql);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            $username = $row["username"];
            $title = $row["title"];
            $v1 = $row["v1"];
            $v2 = $row["v2"];
            $v3 = $row["v3"];
            $v4 = $row["v4"];
            $v5 = $row["v5"];
            $v6 = $row["v6"];
            $v7 = $row["v7"];
            $v8 = $row["v8"];
            $v9 = $row["v9"];
            $v10 = $row["v10"];
            $result2 = $row["result"];

  array_push($list, $v1, $v2, $v3, $v4, $v5, $v6, $v7, $v8, $v9, $v10);
                  }
          } else {
          echo "There are no enquetes";
        }
}
else {



$sql = "SELECT username, title, result, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10 FROM enquete WHERE idUsers = '$id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
          $username = $row["username"];
          $title = $row["title"];
          $v1 = $row["v1"];
          $v2 = $row["v2"];
          $v3 = $row["v3"];
          $v4 = $row["v4"];
          $v5 = $row["v5"];
          $v6 = $row["v6"];
          $v7 = $row["v7"];
          $v8 = $row["v8"];
          $v9 = $row["v9"];
          $v10 = $row["v10"];
          $result2 = $row["result"];

array_push($list, $v1, $v2, $v3, $v4, $v5, $v6, $v7, $v8, $v9, $v10);
                }
        } else {
        echo "There are no enquetes";
      }
    }
?>
<form class="" action="includes/answersubmit.php" method="post">

<?php
echo "<h1 class = 'titlestyle'> Title: ".$title."</h1>";
echo "<h3 class = 'titlestyle'> posted by: ".$username."</h3>";
echo '<input type="text" class = "addquestion" name="username" placeholder = "Enter your name" required>';
foreach ($list as $data) {
  if (empty($data)) {
       continue;
    }

  echo "<h2 class = 'questions'>".$data."</h1>";
  echo '<input type="text" class = "addquestion" name="xyz[]" placeholder = "Enter answer">';
}

  echo '<input type="text" style = "display: none;"name="id" value='.$id.'>';
  echo '<input type="text" style = "display: none;"name="result" value='.$result2.'>';
     ?>
     <center>
       <button type="submit"name="button" class = "button2">Submit</button>
     </center>
</form>


  </body>
</html>
