<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <?php session_start();
    $_SESSION['superhero'] = "lool";
    $_SESSION['result'] = "iets";
    ?>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/popup.css">
    <meta charset="utf-8">
    <title></title>
    <script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous">
  </script>

  <script type="text/javascript" src="../js/submit.js">
  </script>
  </head>
  <body>
  <center><h1>Make a survey</h1></center>
    <form class="" action="includes/submitquestions.php" method="post" id = "enquete" onsubmit="autoclicker()">
      <input class = "title"type="text" id="name" name="username" value="" placeholder = "Enter your name" required>
      <input class = "title"type="text" id="title" name="title" value="" placeholder = "Enter Title" required>
    <center>
      <ul class="ladlist">
        <li class='liclass'><input type="radio" id="contactChoice1"name="choice" value="Public" class="radio"checked>
        <label for="contactChoice1">Public(everybody can acces your survey)</label></li><br>
        <li class='liclass'>  <input type="radio" id="contactChoice2" class="radio" name="choice" value="Private">
        <label for="contactChoice2">Private(Only people with a code can acces your survey)</label></li>
        </ul>
      </center>
      <br>
      <span id = "form">
        <input type="text" class = "addquestion" name="xyz[]" placeholder="Enter your question"value="" required>
      </span>
      <center><button type="button" name="button" class = "button2" id = "button2">Add question</button>
        <button type="submit"name="button" class = "button2" >Submit</button>
      </center>
</form>




<div class="box">
  <a class="button" href="#popup1" id = "button21"></a>
</div>

<div id="popup1" class="overlay">
  <div class="popup">
    <h2>Submit succes</h2>
    <a class="close" href="#">&times;</a>
    <div class="content">
      <p id = "form-message"></p>
    </div>
  </div>
</div>


  </body>
</html>
