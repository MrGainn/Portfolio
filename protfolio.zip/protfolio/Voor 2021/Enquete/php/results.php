<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/main.css">
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <center><h1>Users who filled in your survey:</h1></center>
    <?php
    $code = $_GET['code'];
    require '../dbh/enquetedbh.php';
    $sql = "SELECT id, username FROM answer WHERE result = '$code' ORDER BY id Desc";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                $id = $row["id"];
                $username = $row["username"];
                $id = $row["id"];
                echo "<a class = 'underline' href = 'showresults.php?code=$code&user=$username'>
                    <div class = 'box'>
                      <h1 class = 'titlestyle'>".$username."</h1>
                    </div>
                  </a>";
                }

            }
             else {
            echo "<center><h2>There are no answers</h2></center>";
          }

     ?>
  </body>
</html>
