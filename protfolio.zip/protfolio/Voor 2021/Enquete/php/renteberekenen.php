<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
function rente(){
    $Bedrag = $_POST["bedrag"];
    $Rente = $_POST["rente"];
    $jaar = $_POST["choice"];

    $interest = 1+(0.01*$Rente);

    switch ($jaar) {
      case "4":
        for ($i=1; $i <= 4; $i++) {
          $totaalbedrag = $Bedrag*pow($interest, $i);
          echo "<h3><center>Na ".$i." jaar heb je: <i>".round($totaalbedrag, 2)."</i> euro. </center></h3>";
        }
        break;
      case "10":
        $i = 1;
        while ($i <= 10) {
          $totaalbedrag = $Bedrag*pow($interest, $i);
          echo "<h3><center>Na ".$i." jaar heb je: <i>".round($totaalbedrag, 2)."</i> euro. </center></h3>";
          $i++;
        }
        break;
    }
}
rente();


     ?>
  </body>
</html>
