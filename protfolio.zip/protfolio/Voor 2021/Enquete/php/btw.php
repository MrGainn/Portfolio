<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    function btw(){
    $TotaalBedrag = $_POST["btw"];
    if ($TotaalBedrag > 0) {
      $Btw = ($TotaalBedrag/121) * 21;
      echo "<h1><center>Jouw btw is: €".round($Btw).",-</center></h1>";
      echo "<h4><i><center>Met een btw van 21%</center></i></h4>";
      echo '<center><img src="../img/geld.jpg" alt="Foto van geld"></center>';
    }
    else {
      echo "<center><h2>Geen geldige input</h2></center>";
    }
  }

  btw();


     ?>

  </body>
</html>
