<?php
require "../../host/host.php";
session_start();
$choice = $_POST['choice'];
$resultcode = $_SESSION['result'];
if ($choice == "Private") {
  $hexadecimal = $_SESSION['superhero'];
    echo "Your personal enquete link is: <br><h4><i>".$answerhost.$hexadecimal."</i></h4><br>And your personal code is: ".$resultcode;
}
else {
  echo "Your enquete publicly available <br>And your personal code is: ".$resultcode;
}
?>
