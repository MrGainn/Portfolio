<?php

require '../../dbh/enquetedbh.php';

$id = $_POST['id'];
$username = $_POST['username'];
$result = $_POST['result'];
$v1 = $_POST['xyz'][0];
$v2 = $_POST['xyz'][1];
$v3 = $_POST['xyz'][2];
$v4 = $_POST['xyz'][3];
$v5 = $_POST['xyz'][4];
$v6 = $_POST['xyz'][5];
$v7 = $_POST['xyz'][6];
$v8 = $_POST['xyz'][7];
$v9 = $_POST['xyz'][8];
$v10 = $_POST['xyz'][9];



  $sql = "INSERT INTO answer (id, username, result, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sql)) {
    header("Location: ../create_enquete.php?error=sqlerror2");
  echo "succes";
  }
  else {
    mysqli_stmt_bind_param($stmt, "sssssssssssss", $id, $username, $result, $v1, $v2, $v3, $v4, $v5, $v6, $v7, $v8, $v9, $v10);
    mysqli_stmt_execute($stmt);
    header("Location: ../../index.php?answer=succes");
    }
