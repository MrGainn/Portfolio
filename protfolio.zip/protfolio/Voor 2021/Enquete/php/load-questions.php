<?php

$questioncount = $_POST["questionnewcount"];

for ($x = 0; $x <= $questioncount; $x++) {
  echo '<input type="text" name=""  class = "addquestion" value="">';
  echo "<br>";
}
?>
