<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/main.css">
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="renteberekenen.php" method="post">
    <?php
    echo "<center><h2>Bereken jouw rente na een aantal jaar.</h2></center>";
    echo '<input type="text"name = "bedrag" class = "addquestion"  placeholder = "Noem een bedrag" required>';
    echo '<input type="text" name = "rente" class ="addquestion" placeholder = "Geef je rente in procenten" required>';
     ?>
      <p class = "jaar"> Hoeveel jaar?</p>
     <center>
       <ul class="ladlist">
        <li class='liclass'><input type="radio" id="contactChoice1"name="choice" value="4" class="radio"checked>
        <label for="contactChoice1">4 jaar</label></li><br>
        <li class='liclass'>  <input type="radio" id="contactChoice2" class="radio" name="choice" value="10">
        <label for="contactChoice2">10 jaar</label></li>  <br>
        </ul>
        <button type = 'submit' class = "button3">Bereken</button>

  </center>
   </form>
  </body>
</html>
