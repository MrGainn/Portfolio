<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/main.css">
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="btw.php" method="post">
    <?php
      //We maken een form
      echo "<center><h2>Bereken jouw btw.</h2></center>";
      echo '<input type="text"name = "btw" class = "addquestion"  placeholder = "Noem een bedrag">';
      echo "<center><button class = 'button3' type = 'submit'>Bereken</button></center>";
     ?>
   </form>
  </body>
</html>
