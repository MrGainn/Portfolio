<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="../css/main.css">
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    $code = $_GET['code'];
    $username = $_GET['user'];
  require '../dbh/enquetedbh.php';
    $sql = "SELECT title, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10 FROM enquete WHERE result = '$code'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
              $title = $row["title"];
              $v1 = $row["v1"];
              $v2 = $row["v2"];
              $v3 = $row["v3"];
              $v4 = $row["v4"];
              $v5 = $row["v5"];
              $v6 = $row["v6"];
              $v7 = $row["v7"];
              $v8 = $row["v8"];
              $v9 = $row["v9"];
              $v10 = $row["v10"];


                    }
            }

    $sql = "SELECT username, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10 FROM answer WHERE result = '$code' AND username = '$username'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                $username = $row["username"];
                $a1 = $row["v1"];
                $a2 = $row["v2"];
                $a3 = $row["v3"];
                $a4 = $row["v4"];
                $a5 = $row["v5"];
                $a6 = $row["v6"];
                $a7 = $row["v7"];
                $a8 = $row["v8"];
                $a9 = $row["v9"];
                $a10 = $row["v10"];

                }
echo "<center><h1>Filled in by: ".$username."</h1></center>";
if ($a1 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question1: ".$v1."</i></h2></center>";
echo "<center><h2>answer: ".$a1."</h2></center></div>";
}
if ($a2 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question2: ".$v2."</i></h2></center>";
echo "<center><h2>answer: ".$a2."</h2></center></div>";
}
if ($a3 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question3: ".$v3."</i></h2></center>";
echo "<center><h2>answer: ".$a3."</h2></center></div>";
}
if ($a4 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question4: ".$v4."</i></h2></center>";
echo "<center><h2>answer: ".$a4."</h2></center></div>";
}
if ($a5 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question5: ".$v5."</i></h2></center>";
echo "<center><h2>answer: ".$a5."</h2></center></div>";
}
if ($a6 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question6: ".$v6."</i></h2></center>";
echo "<center><h2>answer: ".$a6."</h2></center></div>";
}
if ($a7 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question7: ".$v7."</i></h2></center>";
echo "<center><h2>answer: ".$a7."</h2></center></div>";
}
if ($a8 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question8: ".$v8."</i></h2></center>";
echo "<center><h2>answer: ".$a8."</h2></center></div>";
}
if ($a9 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question9: ".$v9."</i></h2></center>";
echo "<center><h2>answer: ".$a9."</h2></center></div>";
}
if ($a10 != NULL) {
echo "<div class = 'borderspan'><center><h2><i>Question10: ".$v10."</i></h2></center>";
echo "<center><h2>answer: ".$a10."</h2></center></div>";
}
            }
             else {
            echo "<center><h2>There are no answers</h2></center>";
          }

     ?>





  </body>
</html>
