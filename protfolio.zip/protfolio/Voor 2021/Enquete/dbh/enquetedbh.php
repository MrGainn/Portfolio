<?php

$serverName = "sql106.epizy.com";
$dBUsername = "epiz_27173831";
$dBPassword = "nvBSvsoQEMoENp";
$dBName = "epiz_27173831_enquete";

$conn = mysqli_connect($serverName, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
  die("Connection Failed: ".mysqli_connect_error());
}
