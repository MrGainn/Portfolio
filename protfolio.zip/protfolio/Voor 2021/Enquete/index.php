<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/main.css">
    <meta charset="utf-8">
    <title>Enquete</title>
  </head>
<body>
  <header>
    <form class="" action="php/results.php" method="get"style="inputcode">
      <input type="text" name="code" value="" placeholder = "Enter code" class="codebutton">
      <input type="submit" style="position: absolute; left: -9999px"/>
    </form>
    <span class = "title2">Enquete</span>
    <a href = "php/create_enquete.php">
      <button class="button">
        <span>Create survey</span>
      </button>
    </a>
  </header>

  <img src="img/bannerimg.jpg" class = "homeimg"alt="enquete img">
  <a href = 'php/rente.php' class = "underline">
    <div class = 'box'>
      <h1 class = 'titlestyle'>Bereken samengestelde interest</h1>
    </div>
  </a>
  <a class = "underline" href = 'php/btwberekenen.php'>
    <div class = 'box'>
      <h1 class = 'titlestyle'>btw</h1>
    </div>
  </a>
  <?php
  //De code hieronder zorgt voor alle enquetes die public zijn
  require 'dbh/enquetedbh.php';
  $sql = "SELECT idUsers, title, choice FROM enquete ORDER BY idUsers Desc";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
            $choice = $row["choice"];
            if ($choice != "Private") {


          $title = $row["title"];
          $id = $row["idUsers"];
          echo "<a href = 'php/answer.php?id=$id' class = 'underline'>
              <div class = 'box'>
                <h1 class = 'titlestyle'>".$title."</h1>
              </div>
            </a>";
          }}
        } else {

      }
      ?>
   <footer>
     <img src="img/enquete2.jpg" class = "footerimg"alt="enquete img">
     <span>
       <center>
         <h1 class = "h1">Contact</h1>
      </center>
      <h3>Made by: Aryan and Timon</h3>
      <h3>School: Bonhoeffer college van der Waalslaan</h3>
      <h3>Mobile number: 06-45842400</h3>
      <h3>Email: Test@gmail.com</h3>
      <h3>
    <?php
      date_default_timezone_set("Europe/Amsterdam");
      $today = date("j F y");
      echo "Datum van vandaag is: ".$today;
     ?>
    </h3>
    </span>
  </footer>
</body>
</html>
