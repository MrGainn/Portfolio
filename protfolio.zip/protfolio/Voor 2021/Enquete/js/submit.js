$(document).ready(function(){
  var questioncount = 0;
  $("#button2").click(function(){
    questioncount++;
      if (questioncount < 10) {
        $("#form").append('<input type="text" name="xyz[]" placeholder="Enter your question" class = "addquestion" value="">', {
        });
      }
      else {
        alert("Je kan maximaal 10 vragen hebben");
      }
  });

$("#enquete").submit(function(event){
event.preventDefault();

$.ajax({
method: "post",
url: "includes/submitquestions.php",
data: $("#enquete").serialize(),
datatype: "text",
succes: function (response){
$('#form-message').text(response);
}
})


var name = $("#name").val();
var choice = $(".radio:checked").val();

$("#form-message").load("includes/opensubmit.php", {
name: name,
choice: choice
});


var form = document.getElementById("enquete");
form.reset();

});

});


function autoclicker(){
  document.getElementById("button21").click();
}
