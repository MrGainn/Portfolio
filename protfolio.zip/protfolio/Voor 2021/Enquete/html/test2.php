<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    // Tried to mimic https://dribbble.com/shots/1523277-Success-Popup-for-Handybook-New-App-GIF

.b
.bb
%button#go
  GO
.message
  .check
    &#10004;
  %p
    Success
  %p
    Check your email for a booking confirmation. We'll see you soon!
  %button#ok
    OK

  </body>
</html>
