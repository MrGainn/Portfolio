<?php
$answerhost = "http://enquetesite.epizy.com/Enquete/php/answer.php?type=Private&id=";
