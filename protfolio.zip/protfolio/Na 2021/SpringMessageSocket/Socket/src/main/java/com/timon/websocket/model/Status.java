package com.timon.websocket.model;

public enum Status {
    ONLINE, OFFLINE
}
