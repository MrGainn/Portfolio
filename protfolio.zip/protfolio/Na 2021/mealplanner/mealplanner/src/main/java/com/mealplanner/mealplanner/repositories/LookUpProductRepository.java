package com.mealplanner.mealplanner.repositories;

import com.mealplanner.mealplanner.model.LookUpProduct;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface LookUpProductRepository extends JpaRepository<LookUpProduct, UUID> {


}
