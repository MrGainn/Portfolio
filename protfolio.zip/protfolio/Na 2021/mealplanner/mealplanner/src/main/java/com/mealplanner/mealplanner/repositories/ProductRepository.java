package com.mealplanner.mealplanner.repositories;

import com.mealplanner.mealplanner.model.LookUpProduct;
import com.mealplanner.mealplanner.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ProductRepository extends JpaRepository<Product, UUID> {

}
