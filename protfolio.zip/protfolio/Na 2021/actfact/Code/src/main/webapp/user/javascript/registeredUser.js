$(document).ready(function () {
    var $userTable = $('#user-table');
    var $memberType = $('#member-type');
    var $searchInput = $('.search-input');

    $searchInput.on('input', function () {
        var searchValue = $(this).val().toLowerCase();

        $userTable.find('tbody tr').each(function () {
            var name = $(this).find('td.fullName p').text().trim().toLowerCase();

            if (name.includes(searchValue)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    $memberType.on('change', function () {
        var selectedValue = $(this).val();
        $userTable.find('tbody tr').show();

        if (selectedValue !== 'all') {
            var filterValue = selectedValue === 'members' ? 'User' : 'Admin';
            $searchInput.val('');

            $userTable.find('tbody tr').each(function () {
                var role = $(this).find('td.role p').text().trim();
                if (role !== filterValue) {
                    $(this).hide();
                }
            });
        }
    });
});