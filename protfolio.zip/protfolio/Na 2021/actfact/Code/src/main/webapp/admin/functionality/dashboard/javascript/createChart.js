var xArray;
var yArray;
var xLabel;
var yLabel;
var chartNameAdmin = '';
var chartType;

function getRandomValue() {
    return Math.floor(Math.random() * 256);
}

function generateRandomColors(numColors, opacity) {
    var colors = [];
    for (var i = 0; i < numColors; i++) {
        var color = 'rgba(' + getRandomValue() + ', ' + getRandomValue() + ', ' + getRandomValue() + ', ' + opacity + ')';
        colors.push(color);
    }
    return colors;
}

$(document).ready(function () {
    $('#searchInput').on('keyup', function () {
        var searchText = $(this).val().toLowerCase();

        $('.table-item').each(function () {
            var $tableItem = $(this);
            var tableName = $tableItem.find('.table-name').text().toLowerCase();

            if (tableName.includes(searchText) || isCloseMatch(tableName, searchText)) {
                $tableItem.show();
            } else {
                $tableItem.hide();
            }
        });
    });

    function isCloseMatch(string1, string2) {
        var cleanString1 = string1.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        var cleanString2 = string2.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

        return cleanString1 === cleanString2 || cleanString1.includes(cleanString2);
    }
});

function hideColumn(element) {
    var columnItems = element.nextElementSibling;
    var collapseSign = element.querySelector('.collapse-sign i');
    var columnItemsDisplay = window.getComputedStyle(columnItems).getPropertyValue('display');

    if (columnItemsDisplay === 'none') {
        columnItems.style.display = 'block';
        collapseSign.style.transform = 'rotate(90deg)';
        element.parentNode.classList.remove('collapsed');
    } else {
        columnItems.style.display = 'none';
        collapseSign.style.transform = 'rotate(0deg)';
        element.parentNode.classList.add('collapsed');
    }
}

function handleDragStart(event) {
    const columnName = event.target.dataset.columnName;
    const tableName = event.target.closest('.table-item').querySelector('.table-name').textContent;
    const data = JSON.stringify({columnName, tableName});
    event.dataTransfer.setData("text/plain-origin", data);
}

function handleDragOver(event) {
    event.preventDefault();
}

let myChart = null;
document.addEventListener('DOMContentLoaded', function () {
    let xColumn, xTable, yColumn, yTable;

    var filterSort = document.querySelector('.filter-icon');
    var backButton = document.querySelector('.back-button');
    var containerCbCh = document.querySelector('.container-cb-ch');
    var joinedTable = document.querySelector('.joined-table');
    var showChartOuter = document.querySelector('.chartC-button');

    showChartOuter.addEventListener('click', function () {
        containerCbCh.style.display = 'grid';
        joinedTable.style.display = 'none';
        showChartOuter.style.display = 'none';
        if (myChart) {
            myChart.destroy();
        }
        chartNameAdmin = '';
        createChart();
    });

    filterSort.addEventListener('click', function () {
        containerCbCh.style.display = 'none';
        joinedTable.style.display = 'flex';
    });

    backButton.addEventListener('click', function () {
        containerCbCh.style.display = 'grid';
        joinedTable.style.display = 'none';
    });

    const columnItems = document.querySelectorAll('.column-item');
    columnItems.forEach(function (columnItem) {
        columnItem.addEventListener('dragstart', handleDragStart);
    });

    const inputBoxes = document.querySelectorAll('.input-box');
    inputBoxes.forEach(function (inputBox) {
        inputBox.addEventListener('dragover', handleDragOver);
        inputBox.addEventListener('drop', handleDrop);
    });

    function handleDrop(event) {
        event.preventDefault();
        if (event.dataTransfer.getData("text/plain-origin") === "") {
            return;
        }
        const data = JSON.parse(event.dataTransfer.getData("text/plain-origin"));
        const columnName = data.columnName;
        const tableName = data.tableName;
        event.target.value = columnName;

        const target = event.target;

        if (target.closest('.input-box').classList.contains('x-axis')) {
            xColumn = columnName;
            xTable = tableName;
        } else {
            yColumn = columnName;
            yTable = tableName;
        }
        if (xTable && yTable) {
            if (myChart) {
                myChart.destroy();
            }
            $.ajax({
                url: '/dataRequestServlet',
                type: 'POST',
                data: {
                    xColumn: xColumn,
                    xTable: xTable,
                    yColumn: yColumn,
                    yTable: yTable
                },
                success: function (responseText) {
                    xArray = responseText.xData.split(",");
                    yArray = responseText.yData.split(",");
                    xLabel = xColumn;
                    yLabel = yColumn;
                    chartNameAdmin = '';
                    createChart();
                }
            });
        }
    }

    const modal = document.getElementById('createChart');
    const cancelBtnChart = document.getElementById('cancellationBtnChart');
    cancelBtnChart.addEventListener('click', function () {
        modal.style.display = 'none';
    });

    function createChart() {

        if (!isValidData()) {
            modal.style.display = 'block';
            return;
        }

        chartType = recommendChartType(xArray);
        const recommendedChart = document.querySelector('.show-chart-recommended-' + chartType);
        const allRecommendedCharts = document.querySelectorAll('[class^="show-chart-recommended-"]');
        allRecommendedCharts.forEach(chart => {
            chart.style.display = 'none';
        });
        if (recommendedChart) {
            recommendedChart.style.display = 'flex';
        }
        const borderColor = 'rgba(66, 66, 66, 1)';
        const canvas = document.getElementById('myChart');
        const ctx = canvas.getContext('2d');
        const data = {
            labels: xArray,
            datasets: [
                {
                    label: '',
                    data: yArray,
                    backgroundColor: generateRandomColors(yArray.length, 0.9),
                    borderColor: borderColor,
                    borderWidth: 1,
                },
            ],
        };

        const options = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                    title: {
                        display: true,
                        text: yLabel,
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                },
                x: {
                    ticks: {
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                    title: {
                        display: true,
                        text: xLabel,
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                },
            },
            plugins: {
                title: {
                    display: true,
                    text: chartNameAdmin,
                    font: {
                        family: 'Arial',
                        weight: 'bold',
                        size: 16,
                    },
                    color: 'rgba(0, 0, 0, 1)',
                    padding: {
                        top: 10,
                        bottom: 10,
                    },
                },
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 12,
                        },
                    },
                },
            },
        };

        myChart = new Chart(ctx, {
            type: chartType,
            data: data,
            options: options,
        });

        const chartTypePics = document.querySelectorAll('.show-chart-pic img');

        chartTypePics.forEach(function (chartTypePic) {
            chartTypePic.addEventListener('click', function () {
                chartType = this.parentElement.getAttribute('data-chart-type');

                myChart.config.type = chartType;
                myChart.update();
            });
        });

        const colorsAndStyling = document.getElementById('colorsAndStyling');

        colorsAndStyling.addEventListener('click', function () {
            myChart.data.datasets[0].backgroundColor = generateRandomColors(yArray.length, 0.8);
            myChart.update();
        });

        const downloadButton = document.querySelector('.fa-d');
        downloadButton.addEventListener('click', function () {
            const chartCanvas = document.getElementById('myChart');
            const chartImageURL = chartCanvas.toDataURL('image/png');
            const downloadLink = document.createElement('a');
            downloadLink.href = chartImageURL;
            downloadLink.download = 'chart.png';
            downloadLink.click();
        });

        const openModalButton = document.getElementById('openModal');
        openModalButton.addEventListener('click', function () {
            Swal.fire({
                title: 'CHART ELEMENTS',
                html: `
        <div class="swal-input-box" style="width: 240px;height: 40px;border: 1px solid #ccc; background-color: #F5F1EE; border-radius: 5px; margin-bottom: 15px; margin-left: 105px">
          <input id="chart-name" class="swal-input" type="text" placeholder="Enter Chart Name" style="width: 235px; height: 37px; outline: none; font-size: 15px; background-color: #F5F1EE; border: none; text-align: center;">
        </div>
        <div class="swal-input-box"style="width: 240px;height: 40px;border: 1px solid #ccc; background-color: #F5F1EE; border-radius: 5px; margin-bottom: 15px; margin-left: 105px">
          <input id="xaxis-label" class="swal-input" type="text" placeholder="Enter X-Axis Label" style="width: 235px; height: 37px; outline: none; font-size: 15px; background-color: #F5F1EE; border: none; text-align: center;">
        </div>
        <div class="swal-input-box"style="width: 240px;height: 40px;border: 1px solid #ccc; background-color: #F5F1EE; border-radius: 5px; margin-bottom: 15px; margin-left: 105px">
          <input id="yaxis-label" class="swal-input" type="text" placeholder="Enter Y-Axis Label" style="width: 235px; height: 37px; outline: none; font-size: 15px; background-color: #F5F1EE; border: none; text-align: center;">
        </div>`,
                showCancelButton: true,
                confirmButtonText: 'Save',
                cancelButtonText: 'Cancel',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'swal-button swal-button--primary',
                    cancelButton: 'swal-button',
                },
                didOpen: () => {
                    const confirmButton = Swal.getConfirmButton();
                    const cancelButton = Swal.getCancelButton();
                    confirmButton.style.backgroundColor = '#5C7EAB';
                    confirmButton.style.color = 'white';
                    cancelButton.style.backgroundColor = '#C7CEEA';
                    cancelButton.style.color = 'black';
                    const styleTag = document.createElement('style');
                    styleTag.textContent = '.swal2-popup .swal2-styled:focus {box-shadow: none !important;}';
                    Swal.getPopup().appendChild(styleTag);
                },
                preConfirm: () => {
                    chartNameAdmin = document.getElementById('chart-name').value.trim() || chartNameAdmin;
                    xLabel = document.getElementById('xaxis-label').value.trim() || xLabel;
                    yLabel = document.getElementById('yaxis-label').value.trim() || yLabel;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    myChart.options.plugins.title.text = chartNameAdmin;
                    myChart.options.scales.x.title.text = xLabel;
                    myChart.options.scales.y.title.text = yLabel;
                    myChart.update();
                }
            });
        });
        var showChartInner = document.querySelector('.chartC-button');
        showChartInner.addEventListener('click', function () {
            containerCbCh.style.display = 'grid';
            joinedTable.style.display = 'none';
            showChartInner.style.display = 'none';
            myChart.data.labels = xArray;
            myChart.data.datasets[0].data = yArray;
            myChart.options.scales.x.title.text = xLabel;
            myChart.options.scales.y.title.text = yLabel;
            myChart.options.plugins.title.text = ' ';
            myChart.update();

        });
    }

    function isValidData() {
        for (let i = 0; i < Math.min(1, yArray.length); i++) {
            const value = parseInt(yArray[i]);
            if (isNaN(value)) {
                return false;
            }
        }
        return true;
    }

    function recommendChartType(xArray) {
        const dataType = typeof xArray[0];
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        const uniqueSorted = [...new Set(xArray)].sort();

        if (dateRegex.test(xArray[0])) {
            return 'bar';
        } else if (xArray.length > 8) {
            const dataType = typeof uniqueSorted[0];
            if (dataType === 'number') {
                const isContinuous = uniqueSorted.length >= 8;
                if (isContinuous) {
                    return 'line'
                }
            }
        } else if (dataType === 'string' && uniqueSorted.length >= 5) {
            return 'pie';
        }
        return 'bar'
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('chartSaved');
    const cancelBtn = document.getElementById('cancellationBtnSave');

    const saveButton = document.querySelector('.save-icon');
    saveButton.addEventListener('click', function () {
        if (chartNameAdmin === '' && myChart) {
            Swal.fire({
                title: 'Enter Chart Name',
                input: 'text',
                inputPlaceholder: 'Chart Name',
                showCancelButton: true,
                confirmButtonText: 'Save',
                cancelButtonText: 'Cancel',
                position: 'top',
                inputValidator: function (value) {
                    if (!value || value.trim() === '') {
                        return 'Please enter a valid chart name';
                    }
                },
                didOpen: () => {
                    const confirmButton = Swal.getConfirmButton();
                    const cancelButton = Swal.getCancelButton();
                    confirmButton.style.backgroundColor = '#5C7EAB';
                    confirmButton.style.color = 'white';
                    cancelButton.style.backgroundColor = '#C7CEEA';
                    cancelButton.style.color = 'black';
                }
            }).then(function (result) {
                if (result.isConfirmed) {
                    chartNameAdmin = result.value.trim();
                    saveChart();
                }
            });
        }
        if (chartNameAdmin !== '') {
            saveChart();
        }
    });

    function saveChart() {
        $.ajax({
            url: '/dataSaveServlet',
            type: 'POST',
            data: {
                chartNameAdmin: chartNameAdmin,
                xLabel: xLabel,
                xAxisData: JSON.stringify(xArray),
                yAxisData: JSON.stringify(yArray),
                yLabel: yLabel,
                chartType: chartType
            },
            success: function (responseText) {
                if (responseText === 'success') {
                    modal.style.display = 'block';
                }
            }
        });
    }

    cancelBtn.addEventListener('click', function () {
        modal.style.display = 'none';
    });
});