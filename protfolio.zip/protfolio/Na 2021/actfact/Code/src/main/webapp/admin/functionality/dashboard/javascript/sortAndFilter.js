function handleDragStartTable(event) {
    const columnName = event.target.dataset.columnName;
    const tableName = event.target.closest('.table-item').querySelector('.table-name').textContent;

    const columnList = Array.from(event.target.closest('.table-item').querySelectorAll('.column-item')).map(item => item.textContent.trim());
    const talAndCol = JSON.stringify({columnName, tableName, columnList});
    event.dataTransfer.setData("text/plain", talAndCol);
}

function getCurrentDate() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;

    return formattedDate;
}

document.addEventListener('DOMContentLoaded', function () {
    let Column1, Column1List = [], Table1, Column2, Column2List = [], Table2, Column3, Table3, JoinType;
    const columnItems = document.querySelectorAll('.column-item');
    columnItems.forEach(function (columnItem) {
        columnItem.addEventListener('dragstart', handleDragStartTable);
    });

    const tableInputBoxes = document.querySelectorAll('.input-box1');

    tableInputBoxes.forEach(function (tableInputBox) {
        const input = tableInputBox.querySelector('input');

        input.addEventListener('input', function (event) {
            const target = event.target.parentNode;
            if (event.target.value === "") {
                if (target.classList.contains('table1')) {
                    Column1 = null;
                    Table1 = null;
                    Column1List = [];
                }
                if (target.classList.contains('table2')) {
                    Column2 = null;
                    Table2 = null;
                    Column2List = [];
                }
                if (target.classList.contains('table3')) {
                    Column3 = null;
                    Table3 = null;
                }
            }
        });

        tableInputBox.addEventListener('dragover', handleDragOver);
        tableInputBox.addEventListener('drop', handleTableDrop);
    });

    function handleTableDrop(event) {
        event.preventDefault();
        if (event.dataTransfer.getData("text/plain") === "") {
            return;
        }
        const data = JSON.parse(event.dataTransfer.getData("text/plain"));
        const columnName = data.columnName;
        const tableName = data.tableName;
        const input = event.currentTarget.querySelector('input');
        const columnList = data.columnList;

        input.value = columnName;

        const target = event.target;

        if (target.closest('.input-box1').classList.contains('table1')) {
            Column1 = columnName;
            Table1 = tableName;
            Column1List = columnList;
        }
        if (target.closest('.input-box1').classList.contains('table2')) {
            Column2 = columnName;
            Table2 = tableName;
            Column2List = columnList;
        }
        if (target.closest('.input-box1').classList.contains('table3')) {
            Column3 = columnName;
            Table3 = tableName;
        }
    }

    const joinType = document.getElementById('join-type');
    joinType.addEventListener('change', recordJoinType);

    function recordJoinType(event) {
        JoinType = event.target.value;
    }

    const applyButton = document.querySelector('.apply-button');
    applyButton.addEventListener('click', handleJoin);

    function handleJoin() {
        if (!JoinType) {
            const modal = document.getElementById('selectError');
            const cancelBtn = document.getElementById('cancellationBtnError');
            modal.style.display = 'block';
            cancelBtn.addEventListener('click', function () {
                modal.style.display = 'none';
            });
            return;
        }
        $.ajax({
            url: '/dataJoinServlet',
            type: 'POST',
            dataType: 'json',
            data: {
                Column1: Column1,
                Column1List: JSON.stringify(Column1List),
                Table1: Table1,
                Column2: Column2,
                Column2List: JSON.stringify(Column2List),
                Table2: Table2,
                Column3: Column3,
                Table3: Table3,
                JoinType: JoinType,
            },
            success: function (response) {
                var table = $('.data-table-join');
                var tbody = table.find('tbody');
                tbody.empty();
                var headerRow = $('<tr></tr>');

                headerRow.append('<th style="border: 1px solid #ddd;"><input type="checkbox"></th>');

                for (var columnName in response) {
                    var headerCell = $('<th>' + columnName + '</th>');
                    headerCell.append('<div class="checkboxViewChart">' +
                        '<div class="checkboxOption">' +
                        '<label for="checkboxX1">X-Axis</label>' +
                        '<input type="checkbox" id="checkboxX1"/>' +
                        '</div>' +
                        '<div style="margin-right: 7px;"></div>' +
                        '<div class="checkboxOption">' +
                        '<label for="checkboxY1">Y-Axis</label>' +
                        '<input type="checkbox" id="checkboxY1"/>' +
                        '</div>' +
                        '</div>' +
                        '<div style="margin-top: 7px;"></div>' +
                        '<div class="dropdown-container-sort">' +
                        '<select id="sort-options">' +
                        '<option disabled selected hidden>Select sort</option>' +
                        '<option value="smaller">Less Than</option>' +
                        '<option value="greater">Greater Than</option>' +
                        '<option value="date">Date</option>' +
                        '<option value="groupBy">Group By</option>' +
                        '</select>' +
                        '</div>' +
                        '<div style="margin-top: 7px;"></div>' +
                        '<div class="input-container-value">' +
                        '<input type="text" id="input-box-value" placeholder="Enter value">' +
                        '<button id="go-button">GO</button>' +
                        '</div>');

                    headerRow.append(headerCell);
                }

                table.find('thead').html(headerRow);

                for (var i = 0; i < response[Object.keys(response)[0]].length; i++) {
                    var row = $('<tr></tr>');

                    row.append('<td style="border: 1px solid #ddd;"><input type="checkbox"></td>');

                    for (var columnName in response) {
                        var columnData = response[columnName];
                        row.append('<td>' + columnData[i] + '</td>');
                    }
                    tbody.append(row);
                }

                var Xname, XData, Yname, YData;
                $(document).ready(function () {
                    $('.data-table-join').on('change', '.checkboxOption input[type="checkbox"][id^="checkboxX"]', function () {
                        var columnIndex = $(this).closest('th').index();

                        $('.checkboxOption input[type="checkbox"][id^="checkboxX"]').not(this).prop('checked', false).prop('disabled', false);
                        if (this.checked) {
                            Xname = $('.data-table-join th:eq(' + columnIndex + ')').clone().children().remove().end().text().trim();
                            xLabel = Xname;
                            if ($('.checkboxOption input[type="checkbox"][id^="checkboxY"]:checked').length > 0) {
                                document.getElementById('chartC-button').style.display = 'flex';
                            }
                        } else {
                            document.getElementById('chartC-button').style.display = 'none';
                        }
                        var DataX = $('.data-table-join tr:not(:first)').map(function () {
                            return $(this).find('td:eq(' + columnIndex + ')').text();
                        }).get();
                        XData = JSON.stringify(DataX);
                        xArray = JSON.parse(XData);
                    });
                    $('.data-table-join').on('change', '.checkboxOption input[type="checkbox"][id^="checkboxY"]', function () {
                        var columnIndex = $(this).closest('th').index();

                        $('.checkboxOption input[type="checkbox"][id^="checkboxY"]').not(this).prop('checked', false).prop('disabled', false);
                        if (this.checked) {
                            Yname = $('.data-table-join th:eq(' + columnIndex + ')').clone().children().remove().end().text().trim();
                            yLabel = Yname;
                            if ($('.checkboxOption input[type="checkbox"][id^="checkboxX"]:checked').length > 0) {
                                document.getElementById('chartC-button').style.display = 'flex';
                            }
                        } else {
                            document.getElementById('chartC-button').style.display = 'none';
                        }
                        var DataY = $('.data-table-join tr:not(:first)').map(function () {
                            return $(this).find('td:eq(' + columnIndex + ')').text();
                        }).get();
                        YData = JSON.stringify(DataY);
                        yArray = JSON.parse(YData)
                    });
                });

                $('.data-table-join').on('change', '.dropdown-container-sort #sort-options', function () {
                    var selectedOption = $(this).val();
                    var goButton = $(this).closest('th').find('.input-container-value button#go-button');
                    var inputBox = $(this).closest('th').find('.input-container-value input#input-box-value');

                    if (selectedOption.includes('groupBy')) {
                        inputBox.val('');
                        inputBox.val(Xname + " ➜ " + Yname);
                        goButton.on('click', function () {
                            performGroupBy();
                        });

                    } else if (selectedOption.includes('smaller')) {
                        inputBox.val('');
                        goButton.on('click', function () {
                            performSmaller(inputBox);
                        });
                    } else if (selectedOption.includes('greater')) {
                        inputBox.val('');
                        goButton.on('click', function () {
                            performGreater(inputBox);
                        });
                    } else if (selectedOption.includes('date')) {
                        inputBox.val('');
                        inputBox.val("2000-01-01 " + "TO " + getCurrentDate());
                        goButton.on('click', function () {
                            performDate(inputBox);
                        });
                    } else {
                        inputBox.val('');
                        goButton.off('click');
                    }
                });

                function performDate(inputBox) {
                    var columnIndex = $(inputBox).closest('th').index();
                    var dateRange = inputBox.val().split(' TO ');
                    var startDate = new Date(dateRange[0]);
                    var endDate = new Date(dateRange[1]);

                    table.find('tbody tr').each(function () {
                        var columnData = $(this).find('td').eq(columnIndex).text();
                        var currentDate = new Date(columnData);
                        if (currentDate < startDate || currentDate > endDate) {
                            $(this).remove();
                        }
                    });
                }

                function performGreater(inputBox) {
                    var columnIndex = $(inputBox).closest('th').index();
                    var searchValue = parseInt(inputBox.val());

                    table.find('tbody tr').each(function () {
                        var columnData = $(this).find('td').eq(columnIndex).text();
                        var numericData = parseInt(columnData);

                        if (isNaN(numericData) || numericData <= searchValue) {
                            $(this).remove();
                        }
                    });
                }


                function performSmaller(inputBox) {
                    var columnIndex = $(inputBox).closest('th').index();
                    var searchValue = parseInt(inputBox.val());

                    table.find('tbody tr').each(function () {
                        var columnData = $(this).find('td').eq(columnIndex).text();
                        var numericData = parseInt(columnData);
                        if (isNaN(numericData) || numericData >= searchValue) {
                            $(this).remove();
                        }
                    });
                }


                function performGroupBy() {
                    document.getElementById('chartC-button').style.display = 'none';
                    XData = JSON.parse(XData);
                    YData = JSON.parse(YData);

                    let allNumbers = true;

                    if (isNaN(parseInt(YData[0]))) {
                        allNumbers = false;
                    }

                    const groupedData = XData.reduce((acc, name, index) => {
                        if (acc.hasOwnProperty(name)) {
                            if (allNumbers) {
                                acc[name].counts += parseInt(YData[index]);
                            } else {
                                if (acc[name].hasOwnProperty('counts')) {
                                    acc[name].counts += 1;
                                } else {
                                    acc[name].counts = 1;
                                }
                            }
                        } else {
                            acc[name] = {
                                counts: allNumbers ? parseInt(YData[index]) : 1
                            };
                        }
                        return acc;
                    }, {});

                    let jsonData = JSON.stringify(Object.keys(groupedData).map(name => ({
                        [Xname]: name,
                        [Yname]: groupedData[name].counts
                    })));

                    jsonData = JSON.parse(jsonData);

                    var table = $('.data-table-join');
                    var tbody = table.find('tbody');
                    tbody.empty();
                    var headerRow = $('<tr></tr>');

                    headerRow.append('<th style="border: 1px solid #ddd;"><input type="checkbox"></th>');

                    for (var columnName in jsonData[0]) {
                        var headerCell = $('<th>' + columnName + '</th>');
                        headerCell.append('<div class="checkboxViewChart">' +
                            '<div class="checkboxOption">' +
                            '<label for="checkboxX1">X-Axis</label>' +
                            '<input type="checkbox" id="checkboxX1"/>' +
                            '</div>' +
                            '<div style="margin-right: 7px;"></div>' +
                            '<div class="checkboxOption">' +
                            '<label for="checkboxY1">Y-Axis</label>' +
                            '<input type="checkbox" id="checkboxY1"/>' +
                            '</div>' +
                            '</div>' +
                            '<div style="margin-top: 7px;"></div>' +
                            '<div class="dropdown-container-sort">' +
                            '<select id="sort-options">' +
                            '<option disabled selected hidden>Select sort</option>' +
                            '<option value="smaller">Less Than</option>' +
                            '<option value="greater">Greater Than</option>' +
                            '<option value="date">Date</option>' +
                            '<option value="groupBy">Group By</option>' +
                            '</select>' +
                            '</div>' +
                            '<div style="margin-top: 7px;"></div>' +
                            '<div class="input-container-value">' +
                            '<input type="text" id="input-box-value" placeholder="Enter value">' +
                            '<button id="go-button">GO</button>' +
                            '</div>');

                        headerRow.append(headerCell);
                    }

                    table.find('thead').html(headerRow);

                    jsonData.forEach(rowData => {
                        var row = $('<tr></tr>');
                        row.append('<td style="border: 1px solid #ddd;"><input type="checkbox"></td>');

                        for (var columnName in rowData) {
                            row.append('<td>' + rowData[columnName] + '</td>');
                        }
                        tbody.append(row);
                    });
                }
            },
            error: function (xhr, status, error) {
                const modal = document.getElementById('joinFailed');
                const cancelBtn = document.getElementById('cancellationBtnJoin');
                modal.style.display = 'block';
                cancelBtn.addEventListener('click', function () {
                    modal.style.display = 'none';
                });
            }
        });
    }
});