function hideNames(element) {
    var namesList = element.nextElementSibling;
    var collapseSign = element.querySelector('.collapse-sign i');
    var namesListDisplay = window.getComputedStyle(namesList).getPropertyValue('display');

    if (namesListDisplay === 'none') {
        namesList.style.display = 'block';
        collapseSign.style.transform = 'rotate(90deg)';
        element.classList.remove('collapsed');
    } else {
        namesList.style.display = 'none';
        collapseSign.style.transform = 'rotate(0deg)';
        element.classList.add('collapsed');
    }
}

function getRandomValue() {
    return Math.floor(Math.random() * 256);
}

function generateRandomColors(numColors, opacity) {
    var colors = [];
    for (var i = 0; i < numColors; i++) {
        var color = 'rgba(' + getRandomValue() + ', ' + getRandomValue() + ', ' + getRandomValue() + ', ' + opacity + ')';
        colors.push(color);
    }
    return colors;
}

function handleDragStart(event) {
    document.querySelector('.dashboard-twoBox').style.display = 'none';
    document.querySelector('.dashboard-oneBox').style.display = 'none';
    document.querySelector('.dashboard-dropping-icon').style.display = 'flex';
    const dashboardDroppingStyle = document.querySelector('.dashboard-dropping-section');
    dashboardDroppingStyle.style.justifyContent = 'center';
    dashboardDroppingStyle.style.alignItems = 'center';
    event.dataTransfer.setData("text/plain", event.target.id);
}

function handleDragOver(event) {
    event.preventDefault();
}

$(document).ready(function () {
    $('#searchInput').on('keyup', function () {
        var searchText = $(this).val().toLowerCase();

        $('.dashboard-item').each(function () {
            var $dashboardItem = $(this);
            var dashboardName = $dashboardItem.find('.dashboard-name').text();

            if (dashboardName.toLowerCase().includes(searchText)) {
                var highlightedName = highlightText(dashboardName, searchText);
                $dashboardItem.find('.dashboard-name').html(highlightedName);
                $dashboardItem.show();
            } else {
                $dashboardItem.hide();
            }
        });
    });

    function highlightText(text, search) {
        var regex = new RegExp('(' + escapeRegExp(search) + ')', 'gi');
        return text.replace(regex, '<span class="highlight">$1</span>');
    }

    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
});

document.addEventListener('DOMContentLoaded', function () {
    var dashboardName = document.querySelectorAll('.dashboard-row-container');
    dashboardName.forEach(function (element) {
        element.addEventListener('dragstart', handleDragStart);
        element.addEventListener('dragend', handleDragEnd);
    });

    var dashboardDropping = document.querySelector('.dashboard-dropping-icon');
    dashboardDropping.addEventListener('dragover', handleDragOver);
    dashboardDropping.addEventListener('drop', handleDrop);

    function handleDragEnd(event) {
        const previouslyDroppedItems = document.querySelector('.dashboard-row-container');
        if (previouslyDroppedItems.classList.contains('dropped')) {
            document.querySelector('.dashboard-dropping-icon').style.display = 'none';
            document.querySelector('.dashboard-twoBox').style.display = 'flex';
            document.querySelector('.dashboard-oneBox').style.display = 'flex';
            const dashboardDroppingStyle = document.querySelector('.dashboard-dropping-section');
            dashboardDroppingStyle.style.justifyContent = 'flex-start';
            dashboardDroppingStyle.style.alignItems = 'flex-start';
        }
    }

    function handleDrop(event) {
        event.preventDefault();
        var data = event.dataTransfer.getData("text/plain");

        var droppedItem = document.getElementById(data);
        var previouslyDroppedItems = document.querySelectorAll('.dashboard-row-container.dropped');
        previouslyDroppedItems.forEach(function (item) {
            item.classList.remove("dropped");
        });
        droppedItem.classList.add("dropped");

        document.querySelector('.dashboard-dropping-icon').style.display = 'none';
        document.querySelector('.dashboard-twoBox').style.display = 'flex';
        document.querySelector('.dashboard-oneBox').style.display = 'flex';
        const dashboardDroppingStyle = document.querySelector('.dashboard-dropping-section');
        dashboardDroppingStyle.style.justifyContent = 'flex-start';
        dashboardDroppingStyle.style.alignItems = 'flex-start';

        $.ajax({
            url: '/DashboardDataServlet',
            type: 'POST',
            data: {
                chartData: JSON.stringify(data),
            },
            success: function (responseText) {
                createCharts(responseText);
            }
        });
    }

    function createCharts(chartsData) {
        var chartBox1 = document.querySelector('.chart-box1');
        var chartBox2 = document.querySelector('.chart-box2');
        var chartBox3 = document.querySelector('.chart-box3');
        chartBox1.innerHTML = '';
        chartBox2.innerHTML = '';
        chartBox3.innerHTML = '';


        for (var i = 0; i < chartsData.length; i++) {
            var chartId = chartsData[i].chart_id;
            var chartNameV = chartsData[i].chart_name;
            var chartTypeV = chartsData[i].chart_type;
            var createdByV = chartsData[i].user_id;
            var creationDateV = chartsData[i].creation_date;

            var chartContentBox = document.createElement('div');
            chartContentBox.classList.add('charts-content-box');
            chartContentBox.classList.add('chart-' + chartId);

            var chartsContainer = document.createElement('div');
            chartsContainer.classList.add('charts-container');
            chartsContainer.id = 'charts-container-' + chartId;

            chartContentBox.appendChild(chartsContainer);

            if (i === 0) {
                chartBox1.appendChild(chartContentBox);
            } else if (i === 1) {
                chartBox2.appendChild(chartContentBox);
            } else if (i === 2) {
                chartBox3.appendChild(chartContentBox);
            }

            var canvas = document.createElement('canvas');
            canvas.id = 'chart-' + (i + 1);

            chartsContainer.appendChild(canvas);

            var chartDetails = document.createElement('div');
            chartDetails.classList.add('chart-details');

            var chartName = document.createElement('span');
            chartName.classList.add('chart-name');
            chartName.innerHTML = '<b>Chart Name:</b> ' + chartNameV;
            chartDetails.appendChild(chartName);


            var chartType = document.createElement('span');
            chartType.classList.add('chart-type');
            chartType.innerHTML = '<b>Chart Type:</b> ' + chartTypeV;
            chartDetails.appendChild(chartType);

            var createdBy = document.createElement('span');
            createdBy.classList.add('created-by');
            createdBy.innerHTML = '<b>Created By:</b> ' + createdByV;
            chartDetails.appendChild(createdBy);

            var creationTime = document.createElement('span');
            creationTime.classList.add('creation-time');
            creationTime.innerHTML = '<b>Date:</b> ' + creationDateV;
            chartDetails.appendChild(creationTime);

            chartContentBox.appendChild(chartDetails);
            var ctx = canvas.getContext('2d');

            var dataX = chartsData[i].dataX;
            var dataY = chartsData[i].dataY;
            var labelX = chartsData[i].labelX;
            var labelY = chartsData[i].labelY;

            const borderColor = 'rgba(66, 66, 66, 1)';
            var data = {
                labels: dataX,
                datasets: [{
                    label: ' ',
                    data: dataY,
                    backgroundColor: generateRandomColors(dataY.length, 0.9),
                    borderColor: borderColor,
                    borderWidth: 1,
                }]
            };

            const options = {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            font: {
                                family: 'Arial',
                                weight: 'bold',
                                size: 14,
                            },
                        },
                        title: {
                            display: true,
                            text: labelY,
                            font: {
                                family: 'Arial',
                                weight: 'bold',
                                size: 14,
                            },
                        },
                    },
                    x: {
                        ticks: {
                            font: {
                                family: 'Arial',
                                weight: 'bold',
                                size: 14,
                            },
                        },
                        title: {
                            display: true,
                            text: labelX,
                            font: {
                                family: 'Arial',
                                weight: 'bold',
                                size: 14,
                            },
                        },
                    },
                },
                plugins: {
                    title: {
                        display: true,
                        text: chartNameV,
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 16,
                        },
                        color: 'rgba(0, 0, 0, 1)',
                        padding: {
                            top: 10,
                            bottom: 10,
                        },
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: {
                                family: 'Arial',
                                weight: 'bold',
                                size: 12,
                            },
                        },
                    },
                },
            };

            myChart = new Chart(ctx, {
                type: chartTypeV,
                data: data,
                options: options,
            });
        }
    }
});