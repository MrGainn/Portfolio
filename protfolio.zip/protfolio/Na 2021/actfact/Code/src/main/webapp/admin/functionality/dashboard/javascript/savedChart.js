document.addEventListener('DOMContentLoaded', function () {
    loadCharts()
});

function getRandomValue() {
    return Math.floor(Math.random() * 256);
}

function generateRandomColors(numColors, opacity) {
    var colors = [];
    for (var i = 0; i < numColors; i++) {
        var color = 'rgba(' + getRandomValue() + ', ' + getRandomValue() + ', ' + getRandomValue() + ', ' + opacity + ')';
        colors.push(color);
    }
    return colors;
}

function loadCharts() {
    $.ajax({
        url: '/dataRetrievalServlet',
        type: 'POST',
        success: function (responseText) {
            createCharts(responseText);
        }
    });
}

function handleDeleteChart(event) {
    var chartContentBox = event.target.closest('.charts-content-box');
    var chartId = chartContentBox.classList[1].split('-')[1];
    $.ajax({
        url: '/chartDeleteServlet',
        type: 'POST',
        data: {chartId: chartId},
        success: function (responseText) {
            if (responseText === 'success') {
                Swal.fire({
                    title: 'The chart has been deleted successfully',
                    icon: 'success',
                    position: 'top-end',
                    toast: true,
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer);
                        toast.addEventListener('mouseleave', Swal.resumeTimer);
                    }
                }).then(() => {
                    window.location.href = '/admin/functionality/dashboard/jsp/savedChart.jsp';
                });
            }
        }
    });
}

function handleDragStart(event) {
    event.dataTransfer.setData('text/plain', event.target.id);
}

function handleDragOver(event) {
    event.preventDefault();
}

var savedChartIDs = [];
var dashboardName = '';
document.addEventListener('DOMContentLoaded', function () {
    const creteButton = document.querySelector('.create-button');
    creteButton.addEventListener('click', function () {
        if (savedChartIDs.length > 0) {
            Swal.fire({
                title: 'Enter Dashboard Name',
                input: 'text',
                inputPlaceholder: 'Dashboard Name',
                showCancelButton: true,
                confirmButtonText: 'Save',
                cancelButtonText: 'Cancel',
                position: 'top',
                inputValidator: function (value) {
                    if (!value || value.trim() === '') {
                        return 'Please enter a valid dashboard name';
                    }
                },
                didOpen: () => {
                    const confirmButton = Swal.getConfirmButton();
                    const cancelButton = Swal.getCancelButton();
                    confirmButton.style.backgroundColor = '#5C7EAB';
                    confirmButton.style.color = 'white';
                    cancelButton.style.backgroundColor = '#C7CEEA';
                    cancelButton.style.color = 'black';
                }
            }).then(function (result) {
                if (result.isConfirmed) {
                    dashboardName = result.value.trim();
                    $.ajax({
                        url: '/saveDashboardServlet',
                        type: 'POST',
                        data: {
                            dashboardName: dashboardName,
                            savedChartIDs: JSON.stringify(savedChartIDs)
                        },
                        success: function (responseText) {
                            if (responseText === 'success') {
                                savedChartIDs = [];
                                dashboardName = '';
                                Swal.fire({
                                    title: 'The dashboard has been saved successfully!',
                                    icon: 'success',
                                    position: 'top-end',
                                    toast: true,
                                    showConfirmButton: false,
                                    timer: 3000,
                                    timerProgressBar: true,
                                    didOpen: (toast) => {
                                        toast.addEventListener('mouseenter', Swal.stopTimer);
                                        toast.addEventListener('mouseleave', Swal.resumeTimer);
                                    }
                                }).then(() => {
                                    location.reload();
                                });
                            }
                        }
                    });
                }
            });
        }
    });

    var chartContainers = document.querySelectorAll('.create-dashboard .chart-box');

    chartContainers.forEach(function (container) {
        container.addEventListener('dragover', handleDragOver);
        container.addEventListener('drop', handleDrop);
    });

    function handleDrop(event) {
        event.preventDefault();
        var chartId = event.dataTransfer.getData('text/plain');
        var chartContentBox = document.getElementById(chartId);
        var chartBox = event.target.closest('.chart-box');

        if (chartBox) {

            var existingChart = chartBox.querySelector('.charts-content-box');

            if (existingChart) {
                var sendBack = document.querySelector('.scroll-able');
                sendBack.appendChild(existingChart);

                var chartDetails = existingChart.querySelector('.chart-details');
                chartDetails.style.backgroundColor = 'whitesmoke';
                existingChart.style.backgroundColor = 'whitesmoke';

                var deleteChart = document.createElement('span');
                deleteChart.classList.add('delete-chart');
                deleteChart.innerHTML = '<i class="fas fa-times"></i>';
                existingChart.appendChild(deleteChart);
                deleteChart.addEventListener('click', handleDeleteChart);

                var existingChartID = existingChart.id.replace('chartContentBox-', '');
                var existingChartIndex = savedChartIDs.indexOf(existingChartID);
                if (existingChartIndex > -1) {
                    savedChartIDs.splice(existingChartIndex, 1);
                }

            }

            chartBox.innerHTML = '';
            chartBox.appendChild(chartContentBox);
            var deleteChart = chartBox.querySelector('.delete-chart');
            var chartDetails = chartBox.querySelector('.chart-details');
            var chartsContentBox = chartBox.querySelector('.charts-content-box');
            if (deleteChart) {
                deleteChart.remove();
            }
            chartDetails.style.backgroundColor = '#DBDFEA';
            chartsContentBox.style.backgroundColor = '#DBDFEA';

            var chartNameAndId = chartId.replace('chartContentBox-', '');
            savedChartIDs.push(chartNameAndId);
        }
    }
});

$(document).ready(function () {
    $('#searchInput').on('keyup', function () {
        var searchText = $(this).val().toLowerCase();

        $('.charts-content-box').each(function () {
            var $chartContentBox = $(this);
            var chartName = $chartContentBox.find('.chart-name').text();

            if (chartName.toLowerCase().includes(searchText)) {
                var highlightedName = highlightText(chartName, searchText);
                $chartContentBox.find('.chart-name').html(highlightedName);
                $chartContentBox.show();
            } else {
                $chartContentBox.hide();
            }
        });
    });

    function highlightText(text, search) {
        var regex = new RegExp('(' + escapeRegExp(search) + ')', 'gi');
        return text.replace(regex, '<span class="highlight">$1</span>');
    }

    function escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
});

function createCharts(chartsData) {

    var chartsScroll = document.querySelector('.scroll-able');
    chartsScroll.innerHTML = '';


    for (var i = 0; i < chartsData.length; i++) {
        var chartId = chartsData[i].chart_id;
        var chartNameV = chartsData[i].chart_name;
        var chartTypeV = chartsData[i].chart_type;
        var createdByV = chartsData[i].user_id;
        var creationDateV = chartsData[i].creation_date;

        var chartContentBox = document.createElement('div');
        var chartContentBoxId = 'chartContentBox-' + chartNameV + "-" + chartId;
        chartContentBox.id = chartContentBoxId;
        chartContentBox.classList.add('charts-content-box');
        chartContentBox.classList.add('chart-' + chartId);

        var chartsContainer = document.createElement('div');
        chartsContainer.id = 'charts-container-' + chartId;

        chartContentBox.appendChild(chartsContainer);
        chartsScroll.appendChild(chartContentBox);

        var canvas = document.createElement('canvas');
        canvas.id = 'chart-' + (i + 1);

        chartsContainer.appendChild(canvas);

        var chartDetails = document.createElement('div');
        chartDetails.classList.add('chart-details');

        var chartName = document.createElement('span');
        chartName.classList.add('chart-name');
        chartName.innerHTML = '<b>Chart Name:</b> ' + chartNameV;
        chartDetails.appendChild(chartName);

        var chartType = document.createElement('span');
        chartType.classList.add('chart-type');
        chartType.innerHTML = '<b>Chart Type:</b> ' + chartTypeV;
        chartDetails.appendChild(chartType);

        var createdBy = document.createElement('span');
        createdBy.classList.add('created-by');
        createdBy.innerHTML = '<b>Created By:</b> ' + createdByV;
        chartDetails.appendChild(createdBy);

        var creationTime = document.createElement('span');
        creationTime.classList.add('creation-time');
        creationTime.innerHTML = '<b>Date:</b> ' + creationDateV;
        chartDetails.appendChild(creationTime);

        chartContentBox.appendChild(chartDetails);

        var deleteChart = document.createElement('span');
        deleteChart.classList.add('delete-chart');
        deleteChart.innerHTML = '<i class="fas fa-times"></i>';
        chartContentBox.appendChild(deleteChart);

        deleteChart.addEventListener('click', handleDeleteChart);
        chartContentBox.setAttribute('draggable', true);
        chartContentBox.addEventListener('dragstart', handleDragStart);

        var ctx = canvas.getContext('2d');

        var dataX = chartsData[i].dataX;
        var dataY = chartsData[i].dataY;
        var labelX = chartsData[i].labelX;
        var labelY = chartsData[i].labelY;

        const borderColor = 'rgba(66, 66, 66, 1)';
        var data = {
            labels: dataX,
            datasets: [{
                label: ' ',
                data: dataY,
                backgroundColor: generateRandomColors(dataY.length, 0.9),
                borderColor: borderColor,
                borderWidth: 1,
            }]
        };

        const options = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                    title: {
                        display: true,
                        text: labelY,
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                },
                x: {
                    ticks: {
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                    title: {
                        display: true,
                        text: labelX,
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 14,
                        },
                    },
                },
            },
            plugins: {
                title: {
                    display: true,
                    text: chartNameV,
                    font: {
                        family: 'Arial',
                        weight: 'bold',
                        size: 16,
                    },
                    color: 'rgba(0, 0, 0, 1)',
                    padding: {
                        top: 10,
                        bottom: 10,
                    },
                },
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Arial',
                            weight: 'bold',
                            size: 12,
                        },
                    },
                },
            },
        };

        myChart = new Chart(ctx, {
            type: chartTypeV,
            data: data,
            options: options,
        });
    }
}