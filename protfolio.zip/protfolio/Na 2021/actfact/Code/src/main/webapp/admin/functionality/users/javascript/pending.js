function checkPage() {
    const slide = document.querySelector('.slide');
    const currentPage = window.location.pathname;

    if (currentPage === '/admin/functionality/users/pending.jsp') {
        slide.style.left = '150px';
    } else {
        slide.style.left = '0px';
    }
}

window.addEventListener('load', checkPage);

function leftClick() {
    window.location.href = 'registered.jsp';
}


document.addEventListener('DOMContentLoaded', function () {
    var checkbox = document.getElementById('check');
    var restrictedRows = document.getElementsByClassName('restricted-row');
    var pendingRows = document.getElementsByClassName('pending-row');

    checkbox.addEventListener('change', function () {
        if (checkbox.checked) {
            toggleRows(restrictedRows, 'table-row');
            toggleRows(pendingRows, 'none');
        } else {
            toggleRows(restrictedRows, 'none');
            toggleRows(pendingRows, 'table-row');
        }
    });

    function toggleRows(rows, display) {
        for (var i = 0; i < rows.length; i++) {
            rows[i].style.display = display;
        }
    }
});

function rejectUser(userId) {
    $.ajax({
        url: '/userAccServlet',
        type: 'POST',
        data: {user_Id: userId, text: "restricted"},
        success: function (responseText) {
            if (responseText === 'restricted') {
                Swal.fire({
                    title: 'The account request for User ' + userId + ' has been rejected',
                    icon: 'success',
                    position: 'top-end',
                    toast: true,
                    showConfirmButton: false,
                    timer: 2500,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer);
                        toast.addEventListener('mouseleave', Swal.resumeTimer);
                    }
                }).then(() => {
                    window.location.href = 'pending.jsp';
                });
            }
        }
    });
}

function acceptUser(userId) {
    $.ajax({
        url: '/userAccServlet',
        type: 'POST',
        data: {userId: userId, text: "active"},
        success: function (responseText) {
            if (responseText === 'active') {
                Swal.fire({
                    title: 'User ' + userId + ' has been granted access to all the account functionality.',
                    icon: 'success',
                    position: 'top-end',
                    toast: true,
                    showConfirmButton: false,
                    timer: 2500,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer);
                        toast.addEventListener('mouseleave', Swal.resumeTimer);
                    }
                }).then(() => {
                    window.location.href = 'pending.jsp';
                });
            }
        }
    });
}

$(document).ready(function () {
    var table = $("table");
    var select = $("#sort-type");

    select.on("change", function () {
        var selectedValue = $(this).val();
        var rows = table.find("tbody tr");
        var sortedRows = sortRows(rows, selectedValue);

        table.find("tbody").empty().append(sortedRows);
    });
});

function sortRows(rows, selectedValue) {
    return rows.sort(function (a, b) {
        var dateA = getDateValue($(a).find(".date_created p"));
        var dateB = getDateValue($(b).find(".date_created p"));

        if (selectedValue === "ascending") {
            return dateA - dateB;
        } else if (selectedValue === "descending") {
            return dateB - dateA;
        }
    });
}

function getDateValue(element) {
    if (element.length > 0) {
        var dateValue = element.text().trim();
        return new Date(dateValue);
    }
    return null;
}