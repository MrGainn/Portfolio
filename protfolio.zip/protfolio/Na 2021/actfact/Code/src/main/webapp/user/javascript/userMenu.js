function redirectToDashboard() {
    window.location.href = "/user/jsp/userDashboard.jsp";
}

function redirectToUser() {
    window.location.href = "/user/jsp/registeredUser.jsp";
}

function logout() {
    window.location.href = "/LogoutServlet";
}