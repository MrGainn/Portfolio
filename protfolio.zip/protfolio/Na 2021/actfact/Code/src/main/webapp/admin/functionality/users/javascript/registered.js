function rightClick() {
    window.location.href = 'pending.jsp';
}

function deleteUser(userId) {
    const modal = document.getElementById('deleteConfirmation');
    const deleteBtn = document.getElementById('deleteBtn');
    const cancelBtn = document.getElementById('cancellationBtn');

    modal.style.display = 'block';

    deleteBtn.addEventListener('click', function () {
        $.ajax({
            url: '/deleteServlet',
            type: 'POST',
            data: {userId: userId},
            success: function (responseText) {
                if (responseText === 'success') {
                    Swal.fire({
                        title: 'The user has been deleted successfully.',
                        icon: 'success',
                        position: 'top-end',
                        toast: true,
                        showConfirmButton: false,
                        timer: 2500,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal.stopTimer);
                            toast.addEventListener('mouseleave', Swal.resumeTimer);
                        }
                    }).then(() => {
                        window.location.href = 'registered.jsp';
                    });
                }
            }
        });
        modal.style.display = 'none';
    });
    cancelBtn.addEventListener('click', function () {
        modal.style.display = 'none';
    });
}

function editRole(userId) {
    var roleDisplay = document.getElementById('role_' + userId);
    var roleEdit = document.getElementById('edit_role_' + userId);

    var iconsHide = document.getElementById('icons_' + userId);
    var optionDisplay = document.getElementById('editOptions_' + userId);

    roleDisplay.style.display = 'none';
    roleEdit.style.display = 'inline';

    iconsHide.style.display = 'none';
    optionDisplay.style.display = 'inline';

    roleEdit.value = roleDisplay.innerHTML.trim();

    roleEdit.value = '';

    var placeholderOption = document.createElement('option');
    placeholderOption.value = '';
    placeholderOption.disabled = true;
    placeholderOption.selected = true;
    placeholderOption.innerHTML = 'Choose Role';


    roleEdit.innerHTML = '';


    roleEdit.appendChild(placeholderOption);
    var adminOption = document.createElement('option');
    adminOption.value = 'admin';
    adminOption.innerHTML = 'Admin';

    roleEdit.appendChild(adminOption);

    roleEdit.focus();
}

function saveEdit(userId) {
    var roleEdit = document.getElementById('edit_role_' + userId);

    var selectedRole = roleEdit.value;

    if (!selectedRole) {
        cancelEdit(userId);
        return;
    }

    $.ajax({
        url: '/updateServlet',
        type: 'POST',
        data: {userId: userId, role: selectedRole},
        success: function (responseText) {
            if (responseText === 'update') {
                Swal.fire({
                    title: 'The user role has been updated successfully.',
                    icon: 'success',
                    position: 'top-end',
                    toast: true,
                    showConfirmButton: false,
                    timer: 2500,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer);
                        toast.addEventListener('mouseleave', Swal.resumeTimer);
                    }
                }).then(() => {
                    window.location.href = 'registered.jsp';
                });
            }
        }
    });
}

function cancelEdit(userId) {
    var roleDisplay = document.getElementById('role_' + userId);
    var roleEdit = document.getElementById('edit_role_' + userId);

    var iconsHide = document.getElementById('icons_' + userId);
    var optionDisplay = document.getElementById('editOptions_' + userId);

    roleDisplay.style.display = 'block';
    roleEdit.style.display = 'none';

    iconsHide.style.display = 'block';
    optionDisplay.style.display = 'none';
}

function blockUser(userId) {
    const modal = document.getElementById('confirmationModal');
    const blockBtn = document.getElementById('blockBtn');
    const cancelBtn = document.getElementById('cancelBtn');

    modal.style.display = 'block';

    blockBtn.addEventListener('click', function () {
        $.ajax({
            url: '/updateServlet',
            type: 'POST',
            data: {user_Id: userId, text: 'restricted'},
            success: function (responseText) {
                if (responseText === 'block') {
                    Swal.fire({
                        title: 'The user account has been successfully restricted',
                        icon: 'success',
                        position: 'top-end',
                        toast: true,
                        showConfirmButton: false,
                        timer: 2500,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal.stopTimer);
                            toast.addEventListener('mouseleave', Swal.resumeTimer);
                        }
                    }).then(() => {
                        window.location.href = 'registered.jsp';
                    });
                }
            }
        });
        modal.style.display = 'none';
    });

    cancelBtn.addEventListener('click', function () {
        modal.style.display = 'none';
    });
}

$(document).ready(function () {
    var $userTable = $('#user-table');
    var $memberType = $('#member-type');
    var $searchInput = $('.search-input');

    $searchInput.on('input', function () {
        var searchValue = $(this).val().toLowerCase();

        $userTable.find('tbody tr').each(function () {
            var name = $(this).find('td.fullname p').text().trim().toLowerCase();

            if (name.includes(searchValue)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    $memberType.on('change', function () {
        var selectedValue = $(this).val();
        $userTable.find('tbody tr').show();

        if (selectedValue !== 'all') {
            var filterValue = selectedValue === 'members' ? 'User' : 'Admin';
            $searchInput.val('');

            $userTable.find('tbody tr').each(function () {
                var role = $(this).find('td.role p').text().trim();
                if (role !== filterValue) {
                    $(this).hide();
                }
            });
        }
    });
});