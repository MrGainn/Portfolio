package com.actfact.login.dataRequest;

import com.actfact.login.connection.DBConnection;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(name = "dataRetrievalServlet", value = "/dataRetrievalServlet")
public class dataRetrievalServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();
            String getData = "SELECT * FROM \"ActFact5\".chart ORDER BY chart_id DESC";
            ResultSet resultSet = statement.executeQuery(getData);

            JsonArray jsonArray = new JsonArray();

            while (resultSet.next()) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("user_id", resultSet.getString("user_id"));
                jsonObject.addProperty("chart_type", resultSet.getString("chart_type"));
                jsonObject.add("dataX", new Gson().fromJson(resultSet.getString("dataX"), JsonArray.class));
                jsonObject.add("dataY", new Gson().fromJson(resultSet.getString("dataY"), JsonArray.class));
                jsonObject.addProperty("creation_date", resultSet.getString("creation_date"));
                jsonObject.addProperty("labelX", resultSet.getString("labelX"));
                jsonObject.addProperty("labelY", resultSet.getString("labelY"));
                jsonObject.addProperty("chart_id", resultSet.getInt("chart_id"));
                jsonObject.addProperty("chart_name", resultSet.getString("chart_name"));

                jsonArray.add(jsonObject);
            }

            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonArray.toString());

            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
