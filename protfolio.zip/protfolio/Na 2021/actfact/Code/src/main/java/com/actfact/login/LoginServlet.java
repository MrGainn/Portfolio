package com.actfact.login;

import com.actfact.login.connection.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.sql.*;

@WebServlet(name = "LoginServlet", value = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        HttpSession session = request.getSession(false);

        if (session != null && session.getAttribute("loggedIn") != null && (boolean) session.getAttribute("loggedIn")) {
            String role = (String) session.getAttribute("role");

            if (role.equalsIgnoreCase("admin")) {
                response.sendRedirect("/admin/functionality/dashboard/jsp/savedDashboard.jsp");
                return;
            }
            if (role.equalsIgnoreCase("user")) {
                response.sendRedirect("/user/jsp/userDashboard.jsp");
                return;
            }
        }

        String sqlQuery = "SELECT * FROM \"ActFact5\".\"user\" where user_id = ? ";
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement checkUser = connection.prepareStatement(sqlQuery);
            checkUser.setString(1, username);
            ResultSet rs = checkUser.executeQuery();
            if (rs.next()) {
                session = request.getSession();
                String userID = rs.getString("user_id");
                String hashedPassword = rs.getString("password");
                String role = rs.getString("role");
                String acc_status = rs.getString("status");

                if (acc_status.equalsIgnoreCase("pending")) {
                    request.setAttribute("pending", "Your account is waiting for pending approval");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/login.jsp");
                    dispatcher.forward(request, response);
                    return;
                }
                if (acc_status.equalsIgnoreCase("restricted")) {
                    request.setAttribute("restricted", "Your account is currently restricted");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/login.jsp");
                    dispatcher.forward(request, response);
                    return;
                }

                session.setAttribute("role", role);
                if (BCrypt.checkpw(password, hashedPassword) && role.equalsIgnoreCase("admin")) {
                    String[] firstName = rs.getString("full_name").split(" ");
                    session.setAttribute("userID", userID);
                    session.setAttribute("admin", firstName[0]);
                    session.setAttribute("loggedIn", true);
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/admin/functionality/dashboard/jsp/savedDashboard.jsp");
                    dispatcher.forward(request, response);
                    return;
                }
                if (BCrypt.checkpw(password, hashedPassword)) {
                    String[] firstName = rs.getString("full_name").split(" ");
                    session.setAttribute("user", firstName[0]);
                    session.setAttribute("loggedIn", true);
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/user/jsp/userDashboard.jsp");
                    dispatcher.forward(request, response);
                    return;
                }
            }
            rs.close();
            checkUser.close();
            connection.close();
        } catch (SQLException e) {
            request.setAttribute("loginMessage", "Login failed!");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/login.jsp");
            dispatcher.forward(request, response);
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            request.setAttribute("loginMessage", "Login failed!");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/login.jsp");
            dispatcher.forward(request, response);
            e.printStackTrace();
        }
        if (username != null && password != null)
            request.setAttribute("loginMessage", "Invalid username or password");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/login.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}