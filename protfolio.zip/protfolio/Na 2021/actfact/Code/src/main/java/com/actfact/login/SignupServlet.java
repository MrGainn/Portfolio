package com.actfact.login;

import com.actfact.login.connection.DBConnection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;

@WebServlet(name = "SignupServlet", value = "/SignupServlet")
public class SignupServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        String fullname = request.getParameter("fullname");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt(10));
        String securityQuestion = request.getParameter("securityQuestion");
        String securityAnswer = request.getParameter("securityAnswer");
        final String userRole = "User";
        final String accStatus = "pending";

        LocalDateTime currentDateTime = LocalDateTime.now();
        currentDateTime = currentDateTime.withNano(0);

        Timestamp currentDate = Timestamp.valueOf(currentDateTime);

        String checkQuery = "SELECT * FROM \"ActFact5\".\"user\" where user_id = '" + username + "'";

        String insertQuery = "INSERT INTO \"ActFact5\".\"user\" (user_id, full_name, password, " +
                "security_ques, security_ans, role, date_created, status) VALUES ('" + username + "', '" + fullname + "', '" +
                hashedPassword + "', '" + securityQuestion + "', '" + securityAnswer + "', '" + userRole + "', '" + currentDate + "', '" + accStatus + "')";

        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();
            ResultSet check = statement.executeQuery(checkQuery);

            // Check if the username already exists in the database
            if (check.next()) {
                request.setAttribute("signupMessage", "Username already taken!");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/signup.jsp");
                dispatcher.forward(request, response);
            } else {
                statement.executeUpdate(insertQuery);
                request.setAttribute("signupSuccess", "Account creation successful");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/signup.jsp");
                dispatcher.forward(request, response);
            }
            check.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/signup.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}