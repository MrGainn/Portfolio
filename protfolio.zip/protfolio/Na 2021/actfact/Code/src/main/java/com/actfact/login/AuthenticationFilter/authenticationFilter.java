package com.actfact.login.AuthenticationFilter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebFilter(urlPatterns = {"/admin/*", "/user/*"})
public class authenticationFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        HttpSession session = httpRequest.getSession(false);
        boolean isLoggedIn = session != null && session.getAttribute("loggedIn") != null && (boolean) session.getAttribute("loggedIn");

        if (isLoggedIn) {
            String role = (String) session.getAttribute("role");
            String requestURI = httpRequest.getRequestURI();

            if (role.equalsIgnoreCase("admin") && requestURI.startsWith("/admin/")) {
                chain.doFilter(request, response);
            } else if (role.equalsIgnoreCase("user") && requestURI.startsWith("/user/")) {
                chain.doFilter(request, response);
            } else {
                httpResponse.sendRedirect("/authentication/jsp/unauthorized.jsp");
            }
        } else {
            httpResponse.sendRedirect("/authentication/jsp/login.jsp");
        }
    }
}
