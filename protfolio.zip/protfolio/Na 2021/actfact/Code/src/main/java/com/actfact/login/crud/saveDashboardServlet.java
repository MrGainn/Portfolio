package com.actfact.login.crud;

import com.actfact.login.connection.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(name = "saveDashboardServlet", value = "/saveDashboardServlet")
public class saveDashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String dashboardName = request.getParameter("dashboardName");
        String savedChartIDs = request.getParameter("savedChartIDs");

        String saveDashboard = "INSERT INTO \"ActFact5\".\"dashboard\" (name,saved_charts) VALUES ('" + dashboardName + "', '" + savedChartIDs + "')";

        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();
            statement.executeUpdate(saveDashboard);

            response.setContentType("text/plain");
            response.getWriter().write("success");

            statement.close();
            connection.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
