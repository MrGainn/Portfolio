package com.actfact.login.dataRequest;

import com.actfact.login.connection.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@WebServlet(name = "dataSaveServlet", value = "/dataSaveServlet")
public class dataSaveServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String xLabel = request.getParameter("xLabel").trim();
        String xAxisData = request.getParameter("xAxisData").trim();
        String yLabel = request.getParameter("yLabel").trim();
        String yAxisData = request.getParameter("yAxisData").trim();
        String chartNameAdmin = request.getParameter("chartNameAdmin");

        HttpSession session = request.getSession(false);
        String userID = (String) session.getAttribute("userID");

        String chartType = request.getParameter("chartType");
        chartType = chartType == null ? "bar" : chartType;

        LocalDateTime currentDateTime = LocalDateTime.now();
        currentDateTime = currentDateTime.withNano(0);
        LocalDate currentDate = currentDateTime.toLocalDate();

        try {
            Connection connection = DBConnection.getConnection();

            Statement statement = connection.createStatement();


            String insertQuery = "INSERT INTO \"ActFact5\".\"chart\" (chart_name,user_id, chart_type, \"dataX\", \"dataY\", \"labelX\", \"labelY\", creation_date) VALUES ('" + chartNameAdmin + "', '" +
                    userID + "', '" + chartType + "', '" + xAxisData + "', '" + yAxisData + "', '" + xLabel + "', '" + yLabel + "', '" + currentDate + "')";

            statement.executeUpdate(insertQuery);

            statement.close();
            connection.close();


            response.setContentType("text/plain");
            response.getWriter().write("success");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}