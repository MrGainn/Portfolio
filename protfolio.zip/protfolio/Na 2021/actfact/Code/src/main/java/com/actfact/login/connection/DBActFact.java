package com.actfact.login.connection;

import java.sql.*;

public class DBActFact {
    private static final String host = "bronto.ewi.utwente.nl";

    private static final String dbname = "dab_dda22232b_134";
    private static final String DATABASE_URL = "jdbc:postgresql://" + host + ":5432/" + dbname + "?currentSchema=\"ActFact\"";
    private static final String USER = "dab_dda22232b_134";
    private static final String PASSWORD = "12345678";

    public static Connection actFactConnection() throws SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        return DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
    }

}