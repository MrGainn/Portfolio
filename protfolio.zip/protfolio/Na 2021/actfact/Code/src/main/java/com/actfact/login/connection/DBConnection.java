package com.actfact.login.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String host = "localhost";

    private static final String dbname = "dab_dda22232b_134";
    private static final String DATABASE_URL = "jdbc:postgresql://" + host + ":5431/" + dbname + "?currentSchema=\"ActFact5\"";
    private static final String USER = "dab_dda22232b_134";
    private static final String PASSWORD = "12345678";

    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        return DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
    }
}