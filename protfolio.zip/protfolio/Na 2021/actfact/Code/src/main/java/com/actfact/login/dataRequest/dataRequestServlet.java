package com.actfact.login.dataRequest;

import com.actfact.login.connection.DBActFact;
import com.actfact.login.connection.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(name = "dataRequestServlet", value = "/dataRequestServlet")
public class dataRequestServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String xColumn = request.getParameter("xColumn") != null ? request.getParameter("xColumn").trim() : null;
        String xTable = request.getParameter("xTable") != null ? request.getParameter("xTable").trim() : null;
        String yColumn = request.getParameter("yColumn") != null ? request.getParameter("yColumn").trim() : null;
        String yTable = request.getParameter("yTable") != null ? request.getParameter("yTable").trim() : null;

        try {
            Connection connection = DBActFact.actFactConnection();
            Statement statement = connection.createStatement();

            ResultSet rs = statement.executeQuery("SELECT \"" + xColumn + "\" FROM \"" + xTable + "\"");

            JsonObject jsonData = new JsonObject();


            StringBuilder xData = new StringBuilder();
            while (rs.next()) {
                String value = rs.getString(1);
                xData.append(value).append(",");
            }
            if (xData.length() > 0) {
                xData.deleteCharAt(xData.length() - 1);
            }
            jsonData.addProperty("xData", xData.toString());

            statement.close();
            connection.close();

            connection = DBActFact.actFactConnection();
            statement = connection.createStatement();

            rs = statement.executeQuery("SELECT \"" + yColumn + "\" FROM \"" + yTable + "\"");

            StringBuilder yData = new StringBuilder();
            while (rs.next()) {
                String value = rs.getString(1);
                yData.append(value).append(",");
            }
            if (yData.length() > 0) {
                yData.deleteCharAt(yData.length() - 1);
            }
            jsonData.addProperty("yData", yData.toString());

            statement.close();
            connection.close();

            response.setContentType("application/json");
            response.getWriter().write(jsonData.toString());

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}

