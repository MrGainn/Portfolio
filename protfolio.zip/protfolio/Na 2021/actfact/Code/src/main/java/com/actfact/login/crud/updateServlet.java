package com.actfact.login.crud;

import com.actfact.login.connection.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(name = "updateServlet", value = "/updateServlet")
public class updateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //for blocking user account
        String user_Id = request.getParameter("user_Id");
        String text = request.getParameter("text");
        final String block = "restricted";

        //for changing the user role
        String userId = request.getParameter("userId");
        String selectedRole = request.getParameter("role");
        String capitalizedRole = null;

        if (selectedRole != null && !selectedRole.isEmpty())
            capitalizedRole = selectedRole.substring(0, 1).toUpperCase() + selectedRole.substring(1);

        String updateQuery = "UPDATE \"ActFact5\".\"user\" SET role = '" + capitalizedRole + "' WHERE user_id = '" + userId + "'";

        String blockQuery = "UPDATE \"ActFact5\".\"user\" SET status = '" + block + "' WHERE user_id = '" + user_Id + "'";


        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();

            if (userId !=null && selectedRole.equalsIgnoreCase("admin")) {
                statement.executeUpdate(updateQuery);
                response.setContentType("text/plain");
                response.getWriter().write("update");
            }

            if (user_Id !=null && text.equalsIgnoreCase("restricted")) {
                statement.executeUpdate(blockQuery);
                response.setContentType("text/plain");
                response.getWriter().write("block");
            }

            statement.close();
            connection.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
