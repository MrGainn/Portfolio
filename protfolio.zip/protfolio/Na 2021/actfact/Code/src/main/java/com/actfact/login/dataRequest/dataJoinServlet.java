package com.actfact.login.dataRequest;

import com.actfact.login.connection.DBActFact;
import com.google.gson.Gson;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;


import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet(name = "dataJoinServlet", value = "/dataJoinServlet")
public class dataJoinServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String Column1 = request.getParameter("Column1") != null ? request.getParameter("Column1").trim() : null;
        String Table1 = request.getParameter("Table1") != null ? request.getParameter("Table1").trim() : null;
        String Column2 = request.getParameter("Column2") != null ? request.getParameter("Column2").trim() : null;
        String Table2 = request.getParameter("Table2") != null ? request.getParameter("Table2").trim() : null;
        String Column3 = request.getParameter("Column3") != null ? request.getParameter("Column3").trim() : null;
        String Table3 = request.getParameter("Table3") != null ? request.getParameter("Table3").trim() : null;
        String JoinType = request.getParameter("JoinType").trim().toUpperCase();

        if (Column1 == null || Column1.isEmpty()) {
            Column1 = null;
        }

        if (Column2 == null || Column2.isEmpty()) {
            Column2 = null;
        }

        if (Column3 == null || Column3.isEmpty()) {
            Column3 = null;
        }

        String Column1List = request.getParameter("Column1List");
        String Column2List = request.getParameter("Column2List");

        String joinQuery = "SELECT * FROM \"" + Table1 + "\" " + JoinType + " \"" + Table2 + "\" ON \"" + Table1 + "\".\"" + Column1 + "\" = \"" + Table2 + "\".\"" + Column2 + "\"";

        if (Column2 != null && Column3 != null)
            joinQuery = "SELECT * FROM \"" + Table2 + "\" " + JoinType + " \"" + Table3 + "\" ON \"" + Table2 + "\".\"" + Column2 + "\" = \"" + Table3 + "\".\"" + Column3 + "\"";

        if (Column1 != null && Column3 != null)
            joinQuery = "SELECT * FROM \"" + Table1 + "\" " + JoinType + " \"" + Table3 + "\" ON \"" + Table1 + "\".\"" + Column1 + "\" = \"" + Table3 + "\".\"" + Column3 + "\"";

        if (Column1 != null && Column2 != null && Column3 != null) {
            if (Column1.equalsIgnoreCase(Column2) && Column2.equalsIgnoreCase(Column3)) {

                joinQuery = "SELECT * FROM \"" + Table1 + "\" " + JoinType + " \"" + Table2 + "\" ON \"" + Table1 + "\".\"" + Column1 + "\" = \"" + Table2 + "\".\"" + Column2 + "\"" + JoinType + " \"" + Table3 + "\" ON \"" + Table2 + "\".\"" + Column2 + "\" = \"" + Table3 + "\".\"" + Column3 + "\"";
            }
            if (Column2List.contains(Column3)) {

                joinQuery = "SELECT * FROM \"" + Table1 + "\" " + JoinType + " \"" + Table2 + "\" ON \"" + Table1 + "\".\"" + Column1 + "\" = \"" + Table2 + "\".\"" + Column2 + "\"" + JoinType + " \"" + Table3 + "\" ON \"" + Table2 + "\".\"" + Column3 + "\" = \"" + Table3 + "\".\"" + Column3 + "\"";
            }
            if (Column1List.contains(Column3)) {

                joinQuery = "SELECT * FROM \"" + Table1 + "\" " + JoinType + " \"" + Table2 + "\" ON \"" + Table1 + "\".\"" + Column1 + "\" = \"" + Table2 + "\".\"" + Column2 + "\"" + JoinType + " \"" + Table3 + "\" ON \"" + Table1 + "\".\"" + Column3 + "\" = \"" + Table3 + "\".\"" + Column3 + "\"";
            }
        }

        try {
            Connection connection = DBActFact.actFactConnection();
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = statement.executeQuery(joinQuery);

            Map<String, List<String>> allData = new HashMap<>();
            ResultSetMetaData rsMetaData = rs.getMetaData();
            int columnCount = rsMetaData.getColumnCount();

            for (int i = 1; i <= columnCount; i++) {
                String columnName = rsMetaData.getColumnName(i);

                List<String> columnData = new ArrayList<>();

                while (rs.next()) {
                    String data = rs.getString(columnName);
                    columnData.add(data);
                }
                allData.put(columnName, columnData);
                rs.beforeFirst();
            }

            Gson gson = new Gson();
            String jsonData = gson.toJson(allData);

            response.setContentType("application/json");
            response.getWriter().write(jsonData);

            connection.close();
            statement.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
