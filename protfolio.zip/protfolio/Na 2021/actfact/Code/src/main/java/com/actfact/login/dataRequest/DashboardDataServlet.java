package com.actfact.login.dataRequest;

import com.actfact.login.connection.DBConnection;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(name = "DashboardDataServlet", value = "/DashboardDataServlet")
public class DashboardDataServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String chartData = request.getParameter("chartData");

        String[] dataSplit = chartData.replaceAll("\"", "").split("-");
        String chartID1 = dataSplit.length > 0 ? dataSplit[0] : String.valueOf(0);
        String chartID2 = dataSplit.length > 1 ? dataSplit[1] : String.valueOf(0);
        String chartID3 = dataSplit.length > 2 ? dataSplit[2] : String.valueOf(0);

        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();
            String getChartData = "SELECT * FROM \"ActFact5\".chart " +
                    "WHERE chart_id = '" + chartID1 + "' OR chart_id = '" + chartID2 + "' OR chart_id = '" + chartID3 + "'";
            ResultSet rs = null;
            rs = statement.executeQuery(getChartData);

            JsonArray jsonElements = new JsonArray();

            while (rs.next()) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("user_id", rs.getString("user_id"));
                jsonObject.addProperty("chart_type", rs.getString("chart_type"));
                jsonObject.add("dataX", new Gson().fromJson(rs.getString("dataX"), JsonArray.class));
                jsonObject.add("dataY", new Gson().fromJson(rs.getString("dataY"), JsonArray.class));
                jsonObject.addProperty("creation_date", rs.getString("creation_date"));
                jsonObject.addProperty("labelX", rs.getString("labelX"));
                jsonObject.addProperty("labelY", rs.getString("labelY"));
                jsonObject.addProperty("chart_id", rs.getInt("chart_id"));
                jsonObject.addProperty("chart_name", rs.getString("chart_name"));

                jsonElements.add(jsonObject);
            }
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(jsonElements.toString());

            rs.close();
            statement.close();
            connection.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
