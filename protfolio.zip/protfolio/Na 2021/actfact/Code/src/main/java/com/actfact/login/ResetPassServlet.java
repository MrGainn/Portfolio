package com.actfact.login;

import com.actfact.login.connection.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.sql.*;

@WebServlet(name = "ResetPassServlet", value = "/ResetPassServlet")
public class ResetPassServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        String username = request.getParameter("username");
        String securityQuestion = request.getParameter("securityQuestion");
        String securityAnswer = request.getParameter("securityAnswer");
        String password = request.getParameter("new_password");
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt(10));


        String sqlQuery = "SELECT * FROM \"ActFact5\".\"user\" where user_id = '" + username + "'";

        String updateQuery = "UPDATE \"ActFact5\".\"user\" SET password = '" + hashedPassword + "' WHERE user_id = '" + username + "'";

        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sqlQuery);
            if (rs.next()) {
                String ques = rs.getString("security_ques");
                String ans = rs.getString("security_ans");
                if (securityQuestion.equalsIgnoreCase(ques) && securityAnswer.equalsIgnoreCase(ans)) {
                    statement.executeUpdate(updateQuery);
                    request.setAttribute("resetSuccess", "Password reset is successful");
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/resetpass.jsp");
                    dispatcher.forward(request, response);
                }
            }
        } catch (SQLException e) {
            request.setAttribute("resetMessage", "Password reset failed");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/resetpass.jsp");
            dispatcher.forward(request, response);
        } catch (ClassNotFoundException e) {
            request.setAttribute("resetMessage", "Password reset failed");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/resetpass.jsp");
            dispatcher.forward(request, response);
        }
        if (username != null && securityQuestion != null && securityAnswer != null && password != null)
            request.setAttribute("resetMessage", "Password reset failed");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/authentication/jsp/resetpass.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
