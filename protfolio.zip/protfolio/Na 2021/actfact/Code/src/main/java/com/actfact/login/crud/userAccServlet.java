package com.actfact.login.crud;

import com.actfact.login.connection.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet(name = "userAccServlet", value = "/userAccServlet")
public class userAccServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //for blocking user account
        String user_Id = request.getParameter("user_Id");
        String text_reject = request.getParameter("text");
        final String reject = "restricted";

        //for changing the user role
        String userId = request.getParameter("userId");
        String text_accept = request.getParameter("text");
        final String active = "active";

        String rejectQuery = "UPDATE \"ActFact5\".\"user\" SET status = '" + reject + "' WHERE user_id = '" + user_Id + "'";

        String acceptQuery = "UPDATE \"ActFact5\".\"user\" SET status = '" + active + "' WHERE user_id = '" + userId + "'";

        try {
            Connection connection = DBConnection.getConnection();
            Statement statement = connection.createStatement();

            if (userId != null && text_accept.equalsIgnoreCase(active)) {
                statement.executeUpdate(acceptQuery);
                response.setContentType("text/plain");
                response.getWriter().write("active");
            }

            if (user_Id != null && text_reject.equalsIgnoreCase(reject)) {
                statement.executeUpdate(rejectQuery);
                response.setContentType("text/plain");
                response.getWriter().write("restricted");
            }

            statement.close();
            connection.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
